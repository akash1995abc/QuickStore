import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hii',
  templateUrl: './hii.component.html',
  styleUrls: ['./hii.component.css']
})
export class HiiComponent implements OnInit {
message:string="hello";
msg:string=new Date().toDateString();
  constructor() { }

  ngOnInit() {
  }

}
