<?php 
include("../dbconnection.php");
echo $blogid=$_REQUEST['blogid'];
$blogstatus=$_REQUEST['blogstatus'];
if($blogstatus=='Block')
{
$sql="UPDATE tbl_blogs SET b_status='Unblock' WHERE blog_id='$blogid'";
$result=mysqli_query($con,$sql);
header("location:admin_view_blogs.php?msg=blocked");
}elseif($blogstatus=='Unblock')
{
    $sql22="UPDATE tbl_blogs SET b_status='Block' WHERE blog_id='$blogid'";
$result22=mysqli_query($con,$sql22);
header("location:admin_view_blogs.php?msg=blocked");
}
?>