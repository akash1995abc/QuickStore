<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("adminheader.php");
?>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js">

<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>


<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:30;margin-top:43px;">

  <!-- Header -->
 

  <div class="w3-row-padding w3-margin-bottom">
  <a href="admin_view_districts.php"><div class="w3-quarter">
      <div style="border-radius:6px;margin-right:7px;" class="w3-panel w3-card w3-teal w3-text-white w3-padding-16 w3-hover-white">
        <div class="w3-left"><i class="fa  fa-globe w3-xxxlarge"></i></div>
        <div class="w3-right">
        <?php 
       $sql4="SELECT * FROM tbl_district";
       $result4=mysqli_query($con,$sql4);
       $count4=mysqli_num_rows($result4);
       ?>
          <h3><?php echo $count4; ?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Districts</h4>
      </div>
    </div></a>
    <a href="admin_view_category.php"><div class="w3-quarter">
      <div style="border-radius:6px;margin-right:7px;"  class="w3-panel w3-card w3-teal w3-text-white w3-padding-16 w3-hover-white">
        <div class="w3-left"><i class="fa fa-barcode w3-xxxlarge"></i></div>
        <div class="w3-right">
        <?php 
       $sql1="SELECT * FROM tbl_category";
       $result1=mysqli_query($con,$sql1);
       $count1=mysqli_num_rows($result1);
       ?>
          <h3><?php echo $count1; ?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Categories</h4>
      </div>
    </div></a>
    <a href="admin_view_brands.php"><div class="w3-quarter">
      <div style="border-radius:6px;" class="w3-panel w3-card w3-teal w3-text-white w3-padding-16 w3-hover-white">
        <div class="w3-left"><i class="fa fa-tags w3-xxxlarge"></i></div>
        <div class="w3-right">
        <?php 
       $sql="SELECT * FROM tbl_brands";
       $result=mysqli_query($con,$sql);
       $count=mysqli_num_rows($result);
       ?>
          <h3><?php echo $count; ?></h3>
        </div>
        <div class="w3-clear"></div>
        
        <h4>Brands</h4>
      </div>
    </div></a>
    <a href="admin_view_users.php"><div class="w3-quarter">
      <div style="border-radius:6px;margin-left:7px;" class="w3-panel w3-card w3-teal w3-text-white w3-padding-16 w3-hover-white">
        <div class="w3-left"><i class="fa fa-users w3-xxxlarge"></i></div>
        <div class="w3-right">
        <?php 
       $sql2="SELECT * FROM tbl_user";
       $result2=mysqli_query($con,$sql2);
       $count2=mysqli_num_rows($result2);
       ?>
          <h3><?php echo $count2; ?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Users</h4>
      </div>
    </div></a>
  </div>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <div class="w3-panel">
    <div class="w3-row-padding" style="margin:0 -16px">
      <div class="w3-third">
        <h5>Actions</h5>


<input class="btn btn-info btn-lg w3-hover-white w3-card" data-toggle="modal" data-target="#city"style="width:150px;height:80px;border:none;background:teal;" class="w3-panel w3-card" type="button" value="+Add City">
 <!-- Modal -->
 <div class="modal fade" id="city" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add City</h4>
        </div>
        <div class="modal-body">
        <form action="admin_add_city.php" method="post">
          <select class="w3-select w3-border" name="distid">
          <option value="" disabled selected>Choose District</option>
        
         <?php 
          $sql11="SELECT * FROM tbl_district";
          $result11=mysqli_query($con,$sql11);
          while($row=mysqli_fetch_array($result11))
          {
          ?>
    
    <option  value="<?php echo $row['distid'] ?>"><?php echo $row['dname'] ?></option>
 <?php } ?>
  </select><br><br>
  <input class="w3-input w3-border w3-round" name="city" placeholder="Enter City" type="text">

  <br>
  <input type="submit" class="w3-btn w3-teal" value="Save">
  </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<input class="btn btn-info btn-lg w3-hover-white w3-card" data-toggle="modal" data-target="#district"style="width:150px;height:80px;background:teal;border:none" class="w3-panel w3-card" type="button" value="+Add District">
<!-- Modal -->
<div class="modal fade" id="district" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add District</h4>
        </div>
        <div class="modal-body">
      <form action="admin_add_district.php" method="post">
  <input class="w3-input w3-border w3-round " name="district" placeholder="Enter District Name"type="text"><br>
  <p><input type="submit"class="w3-btn w3-teal" value="Save"></p>
  </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<input class="btn btn-info btn-lg w3-hover-white w3-card" data-toggle="modal" data-target="#category"style="width:150px;height:80px;background:teal;border:none;margin-top:10px;" class="w3-panel w3-card " type="button" value="+Add Category">
<!-- Modal -->
<div class="modal fade" id="category" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Category</h4>
        </div>
        <div class="modal-body">
      <form action="admin_view_category.php" method="post">
  <input class="w3-input w3-border w3-round" name="category" placeholder="Enter Category Name"type="text"><br>
  <p><input type="submit" class="w3-btn w3-teal" value="save"></p>
  </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<input class="btn btn-info btn-lg w3-hover-white w3-card-4" data-toggle="modal" data-target="#brand"style="width:150px;height:80px;border:none;margin-top:10px;background:teal;" class="w3-panel w3-card " type="button" value="+Add Brand">
<!-- Modal -->
<div class="modal fade" id="brand" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Brand</h4>
        </div>
        <div class="modal-body">
      <form action="adminaddbrand.php" method="post">
  <input class="w3-input w3-border w3-round" name="brand" placeholder="Enter Brand Name"type="text"><br>
  <p><button class="w3-btn w3-teal">Save</button></p>
  </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<style>
.chip {
  display: inline-block;
  padding: 0 25px;
  height: 50px;
  font-size: 16px;
  line-height: 50px;
  border-radius: 5px;
  background-color: #f1f1f1;
}

.chip img {
  float: left;
  margin: 0 10px 0 -25px;
  height: 50px;
  width: 50px;
  border-radius: 5px; 
}


#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #fe9126;
  color: white;
}



</style>

      </div>
      <div class="w3-twothird">
        <h5>Stores</h5>
      <?php 
      $status=0;
      $sql="SELECT * FROM tbl_store WHERE sstatus=$status LIMIT 20";
      $result=mysqli_query($con,$sql);
      while($row=mysqli_fetch_array($result))
      {
      ?>  

        <div class="chip w3-card-4 w3-hover-teal">
  <img src="../images/<?php echo $row['simage']?>" alt="Person" width="96" height="96">
  <?php echo $row['sname']?>
</div>
      <?php } ?>



        
      </div>
    </div>
  </div>
  <hr>
  
  <div class="w3-container">
    <h5>Users</h5>
    <table id="customers">
    <tr>
    <th style="background:Teal;">Username</th>
    <th style="background:Teal;">Email</th>
    <th style="background:Teal;">Type</th>
  </tr>
    <?php 
      
      $sql="SELECT * FROM tbl_user WHERE status='Block' AND type='1' OR type='2' LIMIT 5";
      $result=mysqli_query($con,$sql);
      while($row=mysqli_fetch_array($result))
      {
      ?>  
      <tr>
        <td><?php echo $row['uname']?></td>
        <td><?php echo $row['email']?></td>
        <?php 
        $type=$row['type'];
        if($type=='1')
        {
        ?>
          <td>User</td>
        <?php
        }elseif($type=='2')
        {
          ?>
          <td>Shop Owner</td>
        <?php
        }
        
        
        ?>
      
      </tr>
      <?php }?>
      </table><br>
      
     
    <a href="admin_view_users.php"><button class="w3-button w3-dark-grey">View More<i class="fa fa-arrow-right"></i></button></a>
    
  </div>
  
  <hr>

  <div class="w3-container">
    <h5>Recent Blogs</h5>
    <div class="w3-row">
      <div class="w3-col m2 text-center">
      <?php 
      
      $sql="SELECT * FROM tbl_blogs ORDER BY blog_id DESC LIMIT 1";
      $result=mysqli_query($con,$sql);
      while($row=mysqli_fetch_array($result))
      {
      ?> 
        <img class="w3-circle" src="../images/<?php echo $row['photo']?>" style="width:96px;height:96px">
      </div>
      <div class="w3-col m10 w3-container">
      
        <h4><?php echo $row['b_title']?> <span class="w3-opacity w3-medium">Sep 29, 2014, 9:12 PM</span></h4>
        <p>Author:<?php echo $row['author']?></p>
        <p>Recipe type:<?php echo $row['type']?></p>
        <p>Serves:<?php echo $row['serves']?></p><br>
      <?php } ?>
      </div>
    </div>

    </div>
    </br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="admin_view_blogs.php"<button class="w3-button w3-dark-grey">View More<i class="fa fa-arrow-right"></i></button></a>
  </div>
 </br>



<?php include("adminfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>