<?php
include("../dbconnection.php");
 $district=$_REQUEST['district'];
$sql1="SELECT * FROM tbl_district WHERE dname='$district'";
$result1=mysqli_query($con,$sql1);
$count=mysqli_num_rows($result1);
if($count==0)
{
$sql="INSERT INTO tbl_district VALUES (null,'$district')";
$result=mysqli_query($con,$sql);    
header("location:admin_home.php?msg=added");
}else{
    header("location:admin_home.php?msg=already exist");
}
?>