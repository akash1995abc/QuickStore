<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("adminheader.php");

?>
<style>
.header {
  padding: 30px;
  font-size: 40px;
  text-align: center;
  background: white;
}


.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}

/* Add a card effect for articles */
.card {
   background-color: white;
   padding: 20px;
   margin-top: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}


/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {   
    width: 100%;
    padding: 0;
  }
}
</style>

<?php
                    include("../dbconnection.php");
                    $sql="SELECT * FROM tbl_blogs";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    { ?>

<form action="blogapprove.php" method="POST">
<div style="width:45%;padding:10px;display:inline-block;margin-left:45px;" class="w3-card-4">
      <h2><?php echo $row['b_title'] ?></h2>
     
      <div style="height:200px;width:200px;"><img src="../images/<?php echo $row['photo'] ?>" style="height:200px;width:200px;"></div>
      <div style="height:200px;width:200px;float:right;display:inline-block;margin-top:-200px;margin-right:50px;">
      <input type="hidden" name="blogid" value="<?php echo $row['blog_id'] ?>">
  <input type="hidden" name="blogstatus" value="<?php echo $row['b_status'] ?>">
  <input type="submit" class="w3-button w3-red" value="<?php echo $row['b_status'] ?>">
      </div>
    
      <p><b><?php echo $row['ingredients'] ?></b></p></br>
      <p><?php echo $row['instructions'] ?></p>
    
    </div></br></br>
   
  </div>
  
  </form>
             <?php } ?>
  <?php include("adminfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>