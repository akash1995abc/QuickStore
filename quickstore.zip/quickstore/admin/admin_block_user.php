<?php
include("../dbconnection.php");
$uid=$_REQUEST['uid'];
$status=$_REQUEST['status'];
if($status==Block)
{
$sql="UPDATE tbl_user SET status='Unblock' WHERE uid='$uid'";
$result=mysqli_query($con,$sql);
header("location:admin_view_users.php");
}else
{
$sql1="UPDATE tbl_user SET status='Block' WHERE uid='$uid'";
$result1=mysqli_query($con,$sql1);
header("location:admin_view_users.php");
}
?>