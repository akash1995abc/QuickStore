<?php
include("../dbconnection.php");
  $distid=$_REQUEST['distid'];
  $city=$_REQUEST['city'];
 $sql1="SELECT * FROM tbl_city WHERE distid='$distid' AND cname='$city'";
 $result1=mysqli_query($con,$sql1);
 $count=mysqli_num_rows($result1);
 if($count==0)
 {
$sql="INSERT INTO tbl_city VALUES (null,'$distid','$city')";
$result=mysqli_query($con,$sql);    
header("location:admin_home.php?msg=added");
}else{
    header("location:admin_home.php?msg=already exist");
}
?>