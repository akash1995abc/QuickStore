<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("adminheader.php");

?>
<br>
<div class="container">
<center><h3>Available Districts</h3></center>
<input class="w3-input w3-border w3-padding" type="text" placeholder="Search for names.." id="myInput" onkeyup="myFunction()">

<table class="w3-table-all w3-margin-top" id="myTable">
  <tr>
    <th style="width:80%;background:teal;color:WHITE;">Name</th>

    <th style="width:15%;background:teal;color:WHITE;">Status</th>
  </tr>
  <?php 
  $sql="SELECT * FROM tbl_district ORDER BY dname";
  $result=mysqli_query($con,$sql);
  while($row=mysqli_fetch_array($result))
  {
  ?> 
  <tr>
    <td><?php echo $row['dname'] ?></td>
     
    <td>
    <form action="" method="post">
    <input type="hidden" name="uid" value="<?php echo $row['distid'] ?>">
    
    <input type="submit" style="border:none;background:none;color:green;width:100%;height:100%;" value="Available">
    </form>
    </td>
  </tr>
  <?php } ?>
</table>
<br>
</div>
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
<?php include("adminfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>