<?php
include("../dbconnection.php");
echo $brandname=$_REQUEST['brand'];
$sql1="SELECT * FROM tbl_brands WHERE brandname='$brandname'";
$result1=mysqli_query($con,$sql1);
$count=mysqli_num_rows($result1);
if($count==0)
{
$sql="INSERT INTO tbl_brands VALUES (null,'$brandname')";
$result=mysqli_query($con,$sql);    
header("location:admin_home.php?msg=added");
}else{
    header("location:admin_home.php?msg=already exist");
}
?>