<?php include("header.php");?>
<style>
body {
 background-image: url("images/qstore.jpg");
 background-color: #cccccc;
}

</style>
<!-- //navigation -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Register Page</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- register -->
<style>
.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>

 <script language="javascript1.5" type="text/javascript">

function validationForm(signup)
{

	if (document.signup.upass.value!=document.signup.ucpass.value)
    {
		
		alert (" password mismatch.");
        return false;
	}

}
</script> 
<?php
if(isset($_GET['text']))
{
	$text=$_GET['text'];
	?>
	<div class="alert">
	<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
	<strong><?php echo $text ?></strong>
  </div>
  <?php
}
	?>
	


	<div class="register">
		<div class="container">
		
			<div class="login-form-grids">
			<h2>Register Here</h2>
				<form action="signupaction.php" onsubmit="return" class="oh-autoval-form"  name="signup" method="post">
				<input type="text" class="av-name" av-message="Minimum 3 Characters and Alphabets only"  name="uname" placeholder="User Name" ></br>
				<input type="email" class="av-email" av-message="Enter a Valid Email" name="uemail" placeholder="Email Address" required=" " >
                    </br>
				<select name="utype" style="outline: none;border: 1px solid #DBDBDB;padding: 10px 10px 10px 10px;font-size: 14px;color: #999;display: block;width: 100%;">
                <option value="1">Normal User</option>
				<option value="2">Shop Owner</option>
				</select>
				<input name="upass" class="av-password" av-message="must contain uppercase,lowercase,special chars,digits and minimum 6 chars" type="password" placeholder="Password" required=" " >
				<input name="ucpass"  type="password" placeholder="Password Confirmation" required=" " >
				<div class="register-check-box">
					<div class="check">
							
						</div>
					</div>
					<input onclick="return validationForm()" type="submit" value="Register">
				</form>
			</div>
		
		</div>
	</div>




<!-- //register -->
<?php include("footer.php");?>