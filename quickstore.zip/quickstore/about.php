<?php include("header.php");?>
<div class="container">
<h4>About Us</h4>
<h6>QuickStore is an online supermarket portal used to buy products online from your local store and user can collect it either offline or by home delivery
</h6>
</div>  
<?php include("footer.php");?>