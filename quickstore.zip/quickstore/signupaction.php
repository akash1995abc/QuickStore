<?php
include("dbconnection.php");
$u_name=$_POST['uname'];
$u_email=$_POST['uemail'];
$u_type=$_POST['utype'];
$u_pass=$_POST['upass'];
$sql="select * from tbl_user where email='$u_email'";
//$email="select email from tbl_user where email='$u_email ";
$result1=mysqli_query($con,$sql);


if(mysqli_num_rows($result1))
{    
	header("location:../quickstore/signup.php?text=User Already Exist!!!");
}
else
{
$result=mysqli_query($con,"insert into tbl_user values(null,'$u_name','$u_email',$u_type,'$u_pass','Block','Nil')");
header("location:../quickstore/login.php?text=User Registered!!!");
}
?>