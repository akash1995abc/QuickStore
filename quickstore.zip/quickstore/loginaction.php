<?php
session_start();
include("dbconnection.php");

$u_id=$_POST['lemail'];
$u_pass=$_POST['lpassword'];
$sql="SELECT * FROM tbl_user WHERE email='$u_id'";
$result=mysqli_query($con,$sql);

if(!mysqli_num_rows($result))
{
	header("location:../quickstore/login.php?error=Username not found!!");
	exit;
}



$row=mysqli_fetch_array($result);
	
		$dbu_id=$row['uid'];
		$dbu_name=$row['uname'];
		$dbu_email=$row['email'];
		$dbu_type=$row['type'];
		$dbu_pass=$row['password'];
		
		$dbu_status=$row['status'];

		$_SESSION['type']="$dbu_type";
		$_SESSION['email']="$dbu_email";
		$_SESSION['u_id']="$dbu_id";
		$_SESSION['u_pass']="$dbu_h2bpass";
		$_SESSION['u_status']="$dbu_status";

		if($dbu_email==$u_id && $dbu_pass==$u_pass && $dbu_type=='1' )
		{
			if($dbu_status=='Block')
			{
			header("location:user/user_home.php");
			}
			else{
				header("location:../quickstore/login.php?error=User Blocked!!");	
			}

		}
       
        elseif($dbu_email==$u_id && $dbu_pass==$u_pass && $dbu_type=='2')
		{
			if($dbu_status=='Block')
			{
			 
			header("location:store/store_home.php");
		}
		else{
			header("location:../quickstore/login.php?error=User Blocked!!");	
		}
			
		}
		elseif($dbu_email==$u_id && $dbu_pass==$u_pass && $dbu_type=='3' )
		{      
			
			if($dbu_status=='Block')
			{
			header("location:../quickstore/admin/admin_home.php");
			}
			else{
				header("location:../quickstore/login.php?error=User Blocked!!");	
			}
			
		}
		else
		{
			header("location:../quickstore/login.php?error=Wrong password!!");
		}
		


//echo $rowcount;
//echo $u_id;
//echo $u_pass;
?>