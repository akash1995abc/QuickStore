<?php
$to = "jikkumathewalex@mca.ajce.in";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: akash1213.ab@gmail.com" . "\r\n" .
"CC: ajilsunny007@gmail.com.";

mail($to,$subject,$txt,$headers);
?>