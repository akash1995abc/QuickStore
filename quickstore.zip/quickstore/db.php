<?php
$host = '127.0.0.1';
$user = 'root';
$pass = '';
$db = 'quickstore';
$link = mysqli_connect ($host, $user, $pass, $db) or die (mysqli_error()); //die digunakan untuk memberhentikan syntax sampai disini
 ?>

<?php
session_start();
function result ($query) {
  global $link;
  if ($result = mysqli_query($link, $query) or die ('no data')){
  return $result;
  }
}

function run($query) {
  global $link;
  if (mysqli_query ($link, $query)) return true;
  else return false;
  }

function user($username) {
  $query = "SELECT * FROM tbl_user WHERE uname='$username'";
  return result ($query);
}

function update_token($code,$username) {
$query = "UPDATE tbl_user SET token='$code' WHERE uname='$username'";
return run ($query);
}

function update_pass($konfir_pass,$username) {
$query = "UPDATE tbl_user SET password='$konfir_pass' WHERE uname='$username'";
return run ($query);
}
 ?>
