<?php include("header.php");?>
	

		
<!-- //navigation -->
	<!-- main-slider -->
		<ul id="demo1">
			<li>
				<img src="images/11.jpg" alt="" />
				<!--Slider Description example-->
				<div class="slide-desc">
					<h3> Beverage Products Are Now OnLine With Us</h3>
				</div>
			</li>
			<li>
				<img src="images/22.jpg" alt="" />
				  <div class="slide-desc">
					<h3>Whole Household Products Are Now OnLine With Us</h3>
				</div>
			</li>
			
			<li>
				<img src="images/44.jpg" alt="" />
				<div class="slide-desc">
					<h3>Whole Spices Products Are Now OnLine With Us</h3>
				</div>
			</li>
		</ul>
	<!-- //main-slider -->
	<!-- //top-header and slider -->
	<!-- top-brands -->
	
<!-- //top-brands -->
 <!-- Carousel
    ================================================== -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item active">
         <a href="#"> <img class="first-slide" src="images/include/slider1.jpg" alt="First slide"></a>
       
        </div>
        <div class="item">
         <a href="#"> <img class="second-slide " src="images/include/slider2.jpg" alt="Second slide"></a>
         
        </div>
        <div class="item">
          <a href="#"><img class="third-slide " src="images/include/slider3.jpg" alt="Third slide"></a>
          
        </div>
      </div>
    


			<div class="brands">
		<div class="container">
		<h3>Brand Store</h3>
				
				<img style="margin-left:10px;" src="images/include/brands2.jpg" alt="Smiley face" height="200px" width="270px">
				<img style="margin-left:10px;" src="images/include/brands3.jpg" alt="Smiley face" height="200px" width="270px">
				<img style="margin-left:10px;" src="images/include/brands4.jpg" alt="Smiley face" height="200px" width="270px">
				<img style="margin-left:10px;" src="images/include/brands5.jpg" alt="Smiley face" height="200px" width="270px">
				
				<div class="clearfix"></div>
			</div>
		</div>




	</div>
    </div>
			
		

<?php include("footer.php");?>