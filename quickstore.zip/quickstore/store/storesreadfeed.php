<?php 
include("../dbconnection.php");
$storeid=$_REQUEST['storeid'];
$feedid=$_REQUEST['feedid'];
$sql="UPDATE tbl_feedback SET status='read' WHERE feedid='$feedid'";
$result=mysqli_query($con,$sql);
echo "marked as read!";


?>