<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");

?>
  
<div class="container">
 <h2>View Feedback
 </h2>
  
<?php
  
  $storeid=$_REQUEST['storeid'];
  $sql5="SELECT * FROM tbl_feedback WHERE storeid='$storeid' AND status='read'";
  $result5=mysqli_query($con,$sql5);
  while($row5=mysqli_fetch_array($result5))
  {
?>
<div class="w3-card-4" style="width:49%;display: inline-block;margin-top:15px;margin-bottom:15px;">
    <header class="w3-container">
    <div class="w3-panel w3-white w3-card w3-display-container">
    <span style="color:DodgerBlue" class="w3-display-topright w3-padding">✔✔</span>
    </div>
      <h3><?php echo $row5['name'] ?></h3>
    </header>
    
    <div class="w3-container">
      <p><?php echo $row5['message'];?></p>
      <p style="color:BLACK;float:right;"><b><?php echo $row5['uid'] ?></b></p>
    </div>

    <footer class="w3-container w3-green">
      <h5>Recieved-<?php echo $row5['feeddate'] ?></h5>
      
    
    </footer>
 
  </div>
  <?php } ?>
  <h3><a href="store_view_feedback.php?storeid=<?php echo $storeid?>" style="float:right;">
    <span class="fa fa-rotate-left"></span>new
  </a></h3>
</div>

  <?php include("storefooter.php");?>


<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>
