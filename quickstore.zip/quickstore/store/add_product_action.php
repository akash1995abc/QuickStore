<?php 
include("../dbconnection.php");
$pr_name=$_POST['prname'];
$pr_storeid=$_POST['prstoreid'];
$pr_desc=$_POST['prdesc'];
$pr_subcatid=$_POST['prsubcatid'];
$pr_cost=$_POST['prcost'];
$pr_actcost=$_POST['practcost'];
$pr_requantity=$_POST['prrequantity'];
$pr_unitprice=$_POST['prunitprice'];
$pr_expdate=$_POST['prexpdate'];
$product_unit=$_POST['product_unit'];
$upccode=$_POST['upc'];
$brand=$_POST['brand'];
$subcatname=$_POST['subcatname'];
$color=$_POST['color'];
$instock=$_POST['instock'];
$pr_photo= time().$_FILES['photo']['name'];

move_uploaded_file($_FILES['photo']['tmp_name'],"../images/".$pr_photo);

$sql12="SELECT * FROM tbl_products WHERE upc='$upccode'";
$result12=mysqli_query($con,$sql12);
if(mysqli_num_rows($result12))
{  
    header("location:store_add_product.php?scid=$pr_subcatid&storeid=$pr_storeid&subcatname=$subcatname&dltmsg=Already Inserted!"); 
}
else
{

$sql1="INSERT INTO tbl_products VALUES(null,'$pr_name',$pr_storeid,'$pr_desc','$pr_cost','$pr_actcost','$pr_photo',$pr_subcatid,$pr_requantity,'$pr_unitprice','$pr_expdate','$product_unit',$instock,'$color','$upccode','$brand','Available')";
$result1=mysqli_query($con,$sql1);

if($result1)
{   
    $sql="SELECT subcatname FROM tbl_subcategory WHERE subcatid='$pr_subcatid' AND storeid='$pr_storeid' ";
    $result5=mysqli_query($con,$sql);
    $row=mysqli_fetch_array($result5);
    $subcatname=$row['subcatname'];
   header("location:store_add_product.php?scid=$pr_subcatid&storeid=$pr_storeid&subcatname=$subcatname");
    
}
}
// header("location:store_home.php?text=Added!");
?>