<?php
include("../dbconnection.php");
$sname=$_POST['sname'];
$slocation=$_POST['slocation'];
$spincode=$_POST['spincode'];
$slandmark=$_POST['landmark'];
$license=$_POST['license'];
$useremail=$_POST['useremail'];
$sdistrict=$_POST['district'];
$city=$_POST['city'];
if(isset($_POST['shippingcost']))
{
	$shippingcost=$_POST['shippingcost'];
}else
{
	$shippingcost="Nil";
}


$DLV=$_POST['delivery'];
$fileimage = time().$_FILES['photo']['name'];
$sql="SELECT* FROM tbl_store WHERE storename='$sname' AND license='$license'";
$result1=mysqli_query($con,$sql);

if($result1)
{
	header("location:storeprofile.php?text=Store Already Exist!!!");
}
else
{
move_uploaded_file($_FILES['photo']['tmp_name'],"../images/".$fileimage);
$sql="insert into tbl_store values(null,'$sname','$slocation','$spincode','$slandmark','$license','$useremail',$city,'$DLV','$shippingcost','$fileimage','nil',0)";
$result=mysqli_query($con,$sql);

header("location:store_home.php?text=Store Registered");

}
?>
