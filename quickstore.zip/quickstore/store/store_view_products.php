
<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");

?>


 <div class="products">
	 
<div class="container">
<div class="products-right-grid">
	
					<div class="products-right-grids">
				    <form action="storeproductfilter.php" method="post">
						
						<div style="float:left;margin-left:600px"class="sorting-left">
							<select id="country1" name="store">
							<option value="null">Select Store</option>
							<?php 
							$sql43="SELECT * FROM tbl_store WHERE useremail='$u_id'";
							$result43=mysqli_query($con,$sql43);
							while($row43=mysqli_fetch_array($result43))
							{
								
							?>
								<option value="<?php echo $row43['storeid'];?>"><?php echo $row43['sname'];?></option>
								<?php }?>					
							</select>
						
						</div>
						
						<input style="float:right;width:190px;height:36px;" class="w3-border-blue w3-hover-blue"type="submit" value="Filter" >			
						</form>
						<div class="clearfix"> </div>
					</div>
				</div>
<?php
$sql="SELECT * FROM `tbl_user`,`tbl_store`,`tbl_products` WHERE tbl_user.email = tbl_store.useremail AND tbl_store.storeid = tbl_products.pr_storeid AND tbl_user.email='$u_id'";
$result2=mysqli_query($con,$sql);
$count=mysqli_num_rows($result2);
if($count==0)?>

				<div class="w3-container">
  <div class="w3-panel w3-pale-blue w3-leftbar w3-rightbar w3-border-blue">
      <center>	<h3>Products</h3>
			</center>
  </div>
</div>
<?php
while($row=mysqli_fetch_array($result2))
{
?>
<div style="margin-bottom:5px;width:280px;" class=" col-md-4 top_brand_left">
			<div style="border-radius:10px" class="w3-panel w3-card-4  hover14 column">
			<div class="agile_top_brand_left_grid">
			<div class="agile_top_brand_left_grid_pos">
			<img src="../images/offer.png" alt=" " class="img-responsive">
		</div>
		<div class="agile_top_brand_right_grid_pos">
		<a href=""><img  style="width:20px;" src="../images/wsh.png" alt=" " class="img-responsive"></a>
		</div>
<div class=" agile_top_brand_left_grid1">
		<figure>
		<div class="snipcart-item block">
		<div class="snipcart-thumb">
	<a href="#"><img style="width:160px;height:160px;" title=" " alt=" " src="../images/<?php echo $row['pr_image'];?>"></a>		
		<p><?php echo $row['pr_name']?></p>
														
	<h4>₹<?php echo $row['pr_cost']?>.00<span>₹<?php echo $row['pr_actcost']?>.00</span></h4>
		<?php 
		$instock=$row['instock'];
		if($instock<=0)
		{
			$instock="None";
		}
		else
		{
			$instock=$row['instock'];
		}
		?>
   
    <p class="w3-panel w3-pale-grey " style="color:orange;margin-top:-2px;">Expiry:<?php echo$row['pr_expdate'] ?>.</p>
		<p class="w3-panel w3-pale-yellow "style="color:#333;margin-top:-10px;">UPC:<?php echo$row['upc'] ?>.</p>
	
		<p class="w3-panel w3-pale-grey "style="color:INDIGO;margin-top:-10px;"><?php echo$row['pr_status'] ?>.</p>
		
		<p class="w3-panel w3-deep-orange w3-border-blue" style="color:#333;margin-top:-10px;"><?php echo $instock; ?>:in Stock.</p>
	
	</div>
		<div class="snipcart-details top_brand_home_details">
			
									</div>
									</div>
									</figure>
									</div>
									</div>
									</div>
					    			</div>
					
     <?php } ?>
                                                                                
           </div>
           </div>
			


					
					 
<?php include("storefooter.php");?>
<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>