<?php

 include("../dbconnection.php");
 
 $prid=$_POST['prid'];
 $scid=$_POST['scid'];
 $storeid=$_POST['storeid'];
 $name=$_POST['name'];
 $cost=$_POST['cost'];
 $actcost=$_POST['actcost'];
 $requantity=$_POST['requantity'];
 $unitprice=$_POST['unitprice'];
$sql="UPDATE tbl_products SET pr_name='$name',pr_cost='$cost',pr_actcost='$actcost',pr_requantity='$requantity',pr_unitprice='$unitprice' WHERE pr_id='$prid' ";
$result=mysqli_query($con,$sql);
if($result)
{   
    $sql5="SELECT subcatname FROM tbl_subcategory WHERE subcatid='$scid' AND storeid='$storeid' ";
    $result5=mysqli_query($con,$sql5);
    $row=mysqli_fetch_array($result5);
    $subcatname=$row['subcatname'];
header("location:store_add_product.php?scid=$scid&storeid=$storeid&subcatname=$subcatname&dltmsg=Updated!");
}
?>