<?php 
session_start();
include("../dbconnection.php");

$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];


$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");

?>
<!-- this is the jquery for ajax insertion -->
<script>
$(document).ready(function(e){
  $('#submit').click(function(){
   var catid= $('#catid').val();
  
   var storeid=$('#storeid').val();
   var subcat=$('#subcat').val();
   if( subcat==""){
     alert("Enter SubCategory!");
     return false;
   }

  $.ajax({
    type    :'POST',
    data    :{catid:catid,storeid:storeid,subcat:subcat},
    url     :"addsubcat.php",
    success :function(result){
      
     $('#result').html(result);
if(result=="✔") window.location = '';
    }
  })

  });
});
</script>
<!-- this is the jquery for ajax insertion -->


 <form id="myform" name="myform">
<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="store_home.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Product Categories</li>
                <li class="active"><?php 
                base64_decode(base64_encode('name'));
                if(isset($_GET['name']))
                    echo base64_decode($_GET['name']);

                                   ?> -
                 </li>
                
                <input type="hidden" id="catid" name="id" value="<?php   if(isset($_GET['id']))
                echo base64_decode($_GET['id']); 
                $getcatid=base64_decode($_GET['id']);
                ?>">
                <input type="hidden" id="storeid" name="storeid" value="<?php   if(isset($_GET['storeid']))
                echo base64_decode($_GET['storeid']); 
                $storeid=base64_decode($_GET['storeid']);
                ?>">
                
                <li><input style=" padding: 6px;
                                margin-top: 8px;
                                font-size: 15px;
                                border: None" type="text" name="subcat" id="subcat" placeholder="Add Subcategory">
                <input style="background-color:#fe9126;
                                 color:#FFFF;
                                 font-size:16px;
                                 font-weight: bold;
                                 border: 2px;
                                 border-radius:6px;
                                 height:37px; width:100px;" type="button" id="submit" name="submit" value="Add">
                </li>
                <li><span id="result"></span></li>
				
			</ol>
		</div>
	</div>
    </form>






    <h2 align="center">Sub Categories</h2>
		</br>
		<div style="padding-left:50px;padding-right:50px;">
	
        <?php
				$sql="SELECT * FROM tbl_subcategory WHERE catid='$getcatid' AND storeid='$storeid'";
				$result=mysqli_query($con,$sql);
				while($row=mysqli_fetch_array($result))
				{
				?>
 <a style="font-size:100%;" href="store_add_product.php?subcatname=<?php echo $row['subcatname'];?>&cid=<?php echo $row['catid'];?>&scid=<?php echo $row['subcatid'];?>&storeid=<?php echo $row['storeid'];?>">      
<div class="w3-panel w3-card-4 w3-hover-orange" style="padding:20px;border: groove;
  background-color:#FFFF;
  padding: 14px 28px;
  font-size: 16px;
  margin: 15px;
  cursor: pointer;
  display: inline-block;
  border: 6px double #fe9126;width:250px;">
  <i class="glyphicon glyphicon-plus" aria-hidden="true"></i>
<?php echo $row['subcatname']?>

</div>
</a>		
    <?php } ?>                         

	</div>
	<div style="width:20px">&nbsp</div>
  
<?php include("storefooter.php");?>


<?php
 }
else
{
	header("location:../login.php?akash");
}

?>