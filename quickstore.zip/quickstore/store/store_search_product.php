<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");

?>
 <div class="products">
<div class="container">
<?php 
$searchq=$_POST['search'];
$searchq= preg_replace("#[^0-9a-z]#i","",$searchq);
$query= mysqli_query($con,"SELECT * FROM tbl_products WHERE pr_name LIKE '%$searchq%'");
$count = mysqli_num_rows($query);
if($count == 0){

    ?>
    <h4>No Search Results Found!!!</h4>
    <?php
    
}
else{
    while($row = mysqli_fetch_array($query)){
       
?>
<div style="margin-bottom:5px;width:280px;" class=" col-md-4 top_brand_left">
			<div style="border-radius:10px" class="w3-panel w3-card-4  hover14 column">
			<div class="agile_top_brand_left_grid">
			<div class="agile_top_brand_left_grid_pos">
			<img src="../images/offer.png" alt=" " class="img-responsive">
		</div>
		<div class="agile_top_brand_right_grid_pos">
		<a href=""><img  style="width:20px;" src="../images/wsh.png" alt=" " class="img-responsive"></a>
		</div>
<div class=" agile_top_brand_left_grid1">
		<figure>
		<div class="snipcart-item block">
		<div class="snipcart-thumb">
	<a href="#"><img style="width:160px;height:160px;" title=" " alt=" " src="../images/<?php echo $row['pr_image'];?>"></a>		
		<p><?php echo $row['pr_name']?></p>
														
	<h4>₹<?php echo $row['pr_cost']?>.00<span>₹<?php echo $row['pr_actcost']?>.00</span></h4>
	</div>
		<div class="snipcart-details top_brand_home_details">
		<p class=" w3-pale-grey " style="color:orange;margin-top:-2px;">Expiry:<?php echo$row['pr_expdate'] ?>.</p>
		<p class="w3-pale-yellow "style="color:#333;margin-top:-10px;">UPC:<?php echo$row['upc'] ?></p>
	
		<p class="w3-panel w3-pale-grey "style="color:INDIGO;margin-top:-10px;"><?php echo$row['pr_status'] ?>.</p>
		
		<p class="w3-panel w3-deep-orange w3-border-blue" style="color:#333;margin-top:-10px;"><?php echo $row['instock']  ?>:in Stock.</p>
									</div>
									</div>
									</figure>
									</div>
									</div>
									</div>
					    			</div>
					
     <?php 
    }
    }
     ?>
                                                                                
           </div>
           </div>


<?php include("storefooter.php");?>
<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>