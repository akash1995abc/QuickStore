<?php 
session_start();

include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];


$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{ 
?>
<!DOCTYPE html>
<html>
<head>
<title>QuickStore</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Super Market Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="../css/w3.css" rel="stylesheet" type="text/css" media="all" />
<link href="../css/oh-autoval-style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="../css/font-awesome.css" rel="stylesheet"> 

<!-- //font-awesome icons -->
<!-- ajax connection link -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/oh-autoval-script.js"></script>
<script src="../js/jquery.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Raleway:400,100,100italic,200,200italic,300,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<style>
.btn {
  border: groove;
  background-color:#333;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
  display: inline-block;
}

.btn:hover {background: #eee;}

.success {color: green;}
.info {color: dodgerblue;}
.warning {color: orange;}
.danger {color: red;}
.default {color: black;}
</style>

</head>
<body>
<!-- header -->

	<div style="background-color:#3c2f2f " class="logo_products">
		<div class="container">
		
			<div class="w3ls_logo_products_left">
				<h1><a href="store_home.php">QuickStore</a></h1>
			</div>
		<div class="w3l_search">
			<form autocomplete="off" action="store_search_product.php" method="post">
		
			
				
				
				<div class="clearfix"></div>
			</form>
		</div>
			
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //header -->






<!-- navigation -->
	<div class="navigation-agileits">
		<div class="container">
			<nav class="navbar navbar-default">
							<!-- Brand and toggle get grouped for better mobile display -->
							<div class="navbar-header nav_2">
								<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
							</div> 
							<div class="collapse navbar-collapse"  id="bs-megadropdown-tabs">
								<ul class="nav navbar-nav">
									<li><a href="store_home.php" class="act">Home</a></li>	
									<!-- Mega Menu -->
									
									<li><a href="store_view_products.php">Products</a></li>
									
									<li><a href="store_profile.php">Profile</a></li>
									<li><a href="../logout.php">Logout</a></li>
									
								</ul>
							</div>
							</nav>
			</div>
		</div>
<style>
.alert {
  padding: 20px;
  background-color: DodgerBlue;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>
<style>
.collapsible {
  background-color: #333;
  color: white;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
}

.active, .collapsible:hover {
  background-color: #333;
}

.content {
  padding: 0 18px;
  display: none;
  overflow: hidden;
  background-color: #FFFF;
}
</style>

<style>
input,textarea,select{
	outline: none;
	margin-bottom:5px;
	border: 1px solid #DBDBDB;
	padding: 10px 10px 10px 10px;
	font-size: 14px;
	color: #999;
	display: block;
	width: 100%;
}
</style>

<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="store_home.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li >Product Inserion</li>
				<li >Sub Category</li>
				<li ><?php if(isset($_GET['subcatname']))
                        echo $_GET['subcatname'];?></li>
				
			</ol>
		</div>
	</div>

<div class="products">
<div class="container">
<div >
				<div class="categories">
			
					<button  class="collapsible"><center style="">Add Product!</center></button>
<div class="content">
</br>
					<form action="add_product_action.php" onsubmit="return" class="oh-autoval-form" method="post" enctype="multipart/form-data">
					<input style="display:inline;width:49%" type="text" id="prname" name="prname" placeholder="Product Name" required=" " class="av-name" av-message="Minimum 3 characters and alphabets only">
<input  type="hidden" id="prstoreid" name="prstoreid" value="<?php if(isset($_GET['storeid']))
echo $_GET['storeid']; ?>">
					<input type="text" style="display:inline;width:50%" class="av-number" av-message="Positive integer numbers" id="prrequantity" name="prrequantity" placeholder="Product Required Quantity(unit)" required=" ">

					<textarea id="prdesc" name="prdesc" placeholder="Product Description" required=" "></textarea>
					<input type="hidden" id="prsubcatid" name="prsubcatid" value="<?php if(isset($_GET['scid']))
echo $_GET['scid']; ?>">
					<input type="hidden" id="prcatid" name="prcatid" value="<?php if(isset($_GET['catid']))
echo $_GET['catid']; ?>">
					
          
			  	<input  type="text" class="av-price" av-message="Positive integer numbers" id="prcost" name="prcost" placeholder="Product Store Price" required=" " style="display:inline;width:49%">
					<input   type="text" id="prcost" name="practcost" placeholder="Product Actual Price" required="" style="display:inline;width:50%" class="av-price" av-message="Enter Price">

				
				<label style="color:#D3D3D3">Expiry date</label><input  type="month" id="prexpdate" name="prexpdate" placeholder="Product Exp-Date" required=" ">
					<input style="display:inline;width:49%" class="av-number" av-message="Positive integer numbers" type="text" id="prunitprice" name="prunitprice" placeholder="Product Unit Price" required=" ">



					<select style="display:inline;width:50%" name="product_unit" id="product_unit" required>
																						<option value="Nos">Nos</option>
                                            <option value="Bags">Bags</option>
                                            <option value="Bottles">Bottles</option>
                                            <option value="Box">Box</option>
                                            <option value="Dozens">Dozens</option>
                                            <option value="Packet">Packet</option>
                                            <option value="Rolls">Rolls</option>
                                        </select>

						<select style="display:inline;width:49%" name="color" id="color" required>
																						<option value="None">Select Color</option>
                                            <option value="Red">Red</option>
                                            <option value="Blue">Blue</option>
                                            <option value="Yellow">Yellow</option>
                                            <option value="Violet">Violet</option>
                                            <option value="Orange">Orange</option>
                                            <option value="Green">Green</option>
                                        </select>

						<input style="display:inline;width:50%" type="text" id="instock" name="instock" placeholder="Product in Stock" required=" ">
			   <input style="display:inline;width:49%" type="text" id="upc" name="upc" placeholder="Enter 12 digit UPC-Code" required=" ">
				
				 <select style="display:inline;width:50%" name="brand" id="brand" required>
				 <option value="Null">Select Brand</option>
				 <?php 
				 $sql9="SELECT * FROM tbl_brands";
				 $result9=mysqli_query($con,$sql9);
				 while($row9=mysqli_fetch_array($result9))
				 {
				 ?>       
									<option value="<?php echo $row9['brand_id'] ?>"><?php echo $row9['brandname'] ?></option>
			  	<?php } ?>                               
                                        </select>
				 <input type="hidden" id="subcatname" name="subcatname" value="<?php echo $_GET['subcatname']; ?>">

					<input type="file" id="photo" class="av-image" av-message="Select a valid image"  name="photo">

					<input style="background-color: #fe9126;
  											border:none;color: white;width:100%;cursor: pointer;" type="submit" id="submit" value="Insert">
					<span id="result"></span>								 
                    </form>
										</br>
				</div>																																												
			</div>
</div>	</br>
<!-- 	collapsable	 -->
<?php
if(isset($_GET['dltmsg']))
{
	$text=$_GET['dltmsg'];
	?>
	<div class="alert">
	<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
	<strong><?php echo $text ?></strong>
  </div>
  <?php
}
	?>
			<?php 

			include("../dbconnection.php");
			if(isset($_GET['scid']))
			$scid=($_GET['scid']);
			if(isset($_GET['storeid']))
      $storeid=($_GET['storeid']);
			$sql3="SELECT * FROM tbl_products WHERE pr_subcatid='$scid' AND pr_storeid='$storeid'";
			$result3=mysqli_query($con,$sql3);
			while($row=mysqli_fetch_array($result3))
			{
			?>

<form action="editproduct.php" method="post">
<div style="margin:15px;width:255px" class="col-md-4 top_brand_left">
									<div style="border: 1px solid #ddd;
  border-radius: 15px;
  padding: 5px;
  width: 230px;	" class="w3-panel w3-card-2 hover14 column">
										<div class="agile_top_brand_left_grid">
											<div class="agile_top_brand_left_grid_pos">
												<img src="../images/offer.png" alt=" " class="img-responsive">
											</div>
											<div class="agile_top_brand_left_grid1">
												<figure>
													<div class="snipcart-item block">
											<div class="snipcart-thumb">
	<a href="products.html"><img style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 150px;height:180px;" title=" " alt=" " src="../images/<?php echo $row['pr_image'];?>"></a>		
															
														</div>
														<div class="snipcart-details top_brand_home_details">
														<input type="hidden" id="prid" name="prid" value="<?php echo $row['pr_id'];?>">
														<input type="hidden" id="scid" name="scid" value="<?php echo $row['pr_subcatid'];?>">
														<input type="hidden" id="storeid" name="storeid" value="<?php echo $row['pr_storeid'];?>">
														<label style="float:left;">Product Name:</label>
<input type="text"id="name" name="name" value="<?php echo $row['pr_name']?>" style="margin-left:-7px;;width:150px;height:20px;border:none;border-bottom: 5px solid orange;">
<label style="float:left;">Store Price:</label>
<input type="text"  name="cost" value="<?php echo $row['pr_cost']?>" style="margin-left:-7px;;width:150px;height:20px;border:none;border-bottom: 5px solid orange;">
<label style="float:left;">Actual Price:</label>
<input type="text"  name="actcost" value="<?php echo $row['pr_actcost']?>" style="margin-left:-7px;;width:150px;height:20px;border:none;border-bottom: 5px solid orange;">
<label style="float:left;">Required:</label>
<input type="text"  name="requantity" value="<?php echo $row['pr_requantity']?>" style="margin-left:-7px;;width:150px;height:20px;border:none;border-bottom: 5px solid orange;">
<label style="float:left;">Unit Price:</label>
<input type="text"  name="unitprice" value="<?php echo $row['pr_unitprice']?>" style="margin-left:-7px;;width:150px;height:20px;border:none;border-bottom: 5px solid orange;">
</br>

<input type="submit" name="submit" value="Update" class="button">
															</form>
														</div>
													</div>
												</figure>
											</div>
										</div>
									</div>
								</div>

					
			<?php }?>
			<div class="clearfix"> </div>
</div>
</div>


<!-- 	collapsable	 -->
<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}
</script><!-- 	collapsable	 -->
<?php include("storefooter.php");?>

<?php

}
else
{
	header("location:../login.php?akash");
}

?>