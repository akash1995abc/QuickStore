<?php
include("../dbconnection.php");
$storeid=$_REQUEST['storeid'];
$prid=$_REQUEST['prid'];
$instock=$_REQUEST['instock'];
$newstock=$_REQUEST['newstock'];
echo $currentstock=$instock+intval($newstock);
$sql="UPDATE tbl_products SET instock=$currentstock WHERE pr_id=$prid ";
$result=mysqli_query($con,$sql);
header("location:store_view_lowstock.php?storeid=$storeid"); 
?>