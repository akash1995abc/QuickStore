<?php
include("../dbconnection.php");
$ordid=$_REQUEST['odrid'];
$pin=$_REQUEST['pin'];
$sql1="SELECT * FROM tbl_order WHERE ord_id='$ordid'";
$result1=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result1);
$dbpin=$row['pin'];
if($pin!=$dbpin)
{   $storeid=$_REQUEST['storeid'];
    header("location:store_view_orders.php?storeid=$storeid&error=Incorrect Pin");
}else
{
$sql="UPDATE tbl_order SET orderstatus='Delivered' WHERE ord_id='$ordid'";
$result=mysqli_query($con,$sql);
$storeid=$_REQUEST['storeid'];
header("location:store_view_orders.php?storeid=$storeid");
}
?>