<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
 include("storeheader.php");

?>

<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="store_home.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Product Categories</li>
				
			</ol>
		</div>
	</div>

		<h2 align="center">Categories</h2>
		</br>
		<div style="padding-left:50px;padding-right:50px;">
		<?php 
		    $storeid=$_POST['storeid'];
		      
				$sql="SELECT * FROM tbl_category ";
				$result=mysqli_query($con,$sql);
				while($row=mysqli_fetch_array($result))
				{
					$name =base64_encode('name');
				?>
<a href="store_subcat.php?<?php echo $name?>=<?php echo base64_encode($row['catname'])?>&id=<?php echo base64_encode($row['catid'])?>&storeid=<?php echo base64_encode($storeid) ?>">				
<div class="w3-panel w3-card-4 w3-hover-orange" style="padding:20px;border: groove;
  background-color:#FFFF;
  padding: 14px 28px;
  font-size: 16px;
  margin: 15px;
  cursor: pointer;
  display: inline-block;
  border: 6px double #fe9126;width:250px;">
	
<i class="glyphicon glyphicon-plus" aria-hidden="true"></i>
<?php echo $row['catname']?></div></a>
	
    <?php } ?>
	
	</div>
	<div style="width:20px">&nbsp</div>
<?php include("storefooter.php");
 }
else
{
	header("location:../login.php?akash");
}

?>