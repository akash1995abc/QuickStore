<?php
include("../dbconnection.php");
$ordid=$_REQUEST['odrid'];
$sql="UPDATE tbl_order SET orderstatus='Refunded' WHERE ord_id='$ordid'";
$result=mysqli_query($con,$sql);
$storeid=$_REQUEST['storeid'];
header("location:store_view_orders.php?storeid=$storeid");

?>