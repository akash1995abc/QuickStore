<?php
include("../dbconnection.php");
echo $sname=$_REQUEST['sname'];
echo$shippingcost=$_REQUEST['shippingcost'];
echo$delivery=$_REQUEST['delivery'];
echo$storeid=$_REQUEST['storeid'];
$map=$_REQUEST['map'];
$fileimage = time().$_FILES['photo']['name'];
move_uploaded_file($_FILES['photo']['tmp_name'],"../images/".$fileimage);

$sql="UPDATE tbl_store SET sname='$sname',shippingcost='$shippingcost',delivery='$delivery',simage='$fileimage',map='$map' WHERE storeid='$storeid'";
$result=mysqli_query($con,$sql);
header("location:store_home.php");

?>