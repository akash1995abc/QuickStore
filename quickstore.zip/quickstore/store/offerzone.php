<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");

?>


<style>

.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
* {
  box-sizing: border-box;
}

/* Add a gray background color with some padding */


/* Header/Blog Title */
.header {
  padding: 30px;
  font-size: 40px;
  text-align: center;
  background: white;
}

/* Fake image */
.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}

/* Add a card effect for articles */
.card {
   background-color: white;
   padding: 20px;
   margin-top: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {   
    width: 100%;
    padding: 0;
  }
}
</style>

<div style="padding: 30px;
  font-size: 40px;
  text-align: center;
  background: #FFFFD;">
 <input type="button" class="w3-hover-blue" id="myBtn" style="float:right; background-color: #4CAF50;
                            border: none;
                            color: white;
                            padding: 15px 32px;
                            text-align: center;
                            text-decoration: none;
                            display: inline-block;
                            font-size: 16px;
                            margin: 4px 2px;
                            cursor: pointer;" value="Add New">
  <h2 style="color:#D3D3D3;">    .   </h2>
</div>
<?php 
include("../dbconnection.php");
$date=date("Y/m/d");
$storeid=$_REQUEST['storeid'];
$sql8="DELETE FROM tbl_offers WHERE date!='$date'";
$result8=mysqli_query($con,$sql8);
$sql="SELECT * FROM tbl_offers WHERE status='valid' AND date='$date' AND storeid='$storeid'";
$result=mysqli_query($con,$sql);
$count=mysqli_num_rows($result);
if($count==0)
{
    echo "Post Some Ads!";
}
else{

while($row=mysqli_fetch_array($result))
{
?>
    <div style="display: inline-block;margin-left:30px;"class="card">
    
      <div style="height:200px;width:270px" ><img style="height:200px;width:270px" src="../images/<?php echo $row['adimg'] ?>">
     
     
      <button style="background:#4CAF50;width:100%;border:none;height:30px;">Valid for :<?php echo $row['date']; ?></button>
      
      </div></br>
      <p></p>
     
    </div>
<?php } }?>   
<hr>

<!-- The Modal -->
<div id="myModal" class="modal">
  <!-- Modal content -->
  <form action="storeaddoffer.php" method="post" onsubmit="return" class="oh-autoval-form" enctype="multipart/form-data">
  <div class="modal-content">
    <span class="close">&times;</span>
    <p>New Advertisement</p></br>
    <?php $storeid=$_REQUEST['storeid']; ?>
     <input type="hidden" name="storeid" value="<?php echo $storeid ?>">
    <input type="file"  name="photo" id="photo" class="av-image" av-message="Select a valid image">   </br>
    <input type="submit" value="Add offer" placeholder="Enter Content" style="outline: none;padding: 10px 10px 10px 10px;
    border: 1px solid #333;font-size: 14px;background-color:#333;color:white;display: block;width: 100%; " >
    
    
  </div>
  </form>
</div>

<script>

// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
<script>

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active1");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}
</script>

<?php include("storefooter.php");?>


<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>
