<?php 
include("../dbconnection.php");
$catid=$_REQUEST['catid'];
$subcat=$_REQUEST['subcat'];
$storeid=$_REQUEST['storeid'];
$sql1="SELECT * FROM tbl_subcategory WHERE catid='$catid' AND subcatname='$subcat' AND storeid='$storeid'";
$result11=mysqli_query($con,$sql1);
$count=mysqli_num_rows($result11);
if($count!=0)
{
    echo "already available";
}else{


$sql="INSERT INTO tbl_subcategory VALUES(null,$catid,'$subcat',$storeid)";
$result1=mysqli_query($con,$sql);
if($result1){
    echo '✔';
}
}
// header("location:store_home.php?text=Added!");
?>