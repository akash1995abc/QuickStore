<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");

?>
<style>
table {
  border-collapse: collapse;
  width: 100%;
  margin-top:50px;
  margin-bottom:50px;
}

th, td {
  text-align: left;
  padding: 12px;
  height:40px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #ddd;
  color: black;
}
</style>



<?php 
if(isset($_REQUEST['error']))
{
$error=$_REQUEST['error']; ?>
<div class="w3-panel w3-yellow w3-display-container">
  <span onclick="this.parentElement.style.display='none'"
  class="w3-button w3-large w3-display-topright">&times;</span>
  <h3><?php echo $error; ?>!</h3>
  <p>Enter the correct invoice generated PIN</p>
</div>
<?php }?>
<div id="tab">
<table>

<tr>
    <th style="width:20px;">&nbsp;OrderDate</th>
    
    <th style="background:#D3D3D3">User</th>
    <th>Address</th>
    <th style="background:#D3D3D3">Phone</th>
    <th>Postcode</th>
    <th style="background:#D3D3D3">Payment</th>
    <th style="width:60px;">Pin</th>
    <th style="background:#D3D3D3">Total Amount</th>
    
    <th>Delivery</th>
<?php
  
   $storeid=$_REQUEST['storeid'];
   $sql5="SELECT * FROM tbl_order WHERE storeid='$storeid' AND orderstatus='ND'";
   $result5=mysqli_query($con,$sql5);
   while($row5=mysqli_fetch_array($result5))
   {
 ?>


  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row5['date']?></td>
    <td style="color:#f44336"><?php echo $row5['u_id']?></td>
    <td><?php echo $row5['address']?></td>
    <td style="color:#f44336"><?php echo $row5['phone']?></td>
    <td><?php echo $row5['postcode']?></td>
    <td style="color:#f44336"><?php echo $row5['status']?></td>
    <form action="storeapprovedelivery.php" method="post">
    <td style="width:60px;"><input type="text" name="pin" style="width:50px;border:none;" autocomplete=OFF required=""placeholder="✖✖✖✖"></td>
    <td style="color:#f44336">₹<?php echo $row5['total']?></td>
    
    <td style="background:#f44336;border:solid;color:WHITE;"id="click">
    
    <input type="hidden" name="odrid" value="<?php echo $row5['ord_id']?>">
    <input type="hidden" name="storeid" value="<?php echo $storeid; ?>">
    <input type="submit" style="margin-top:10px;height:100%;width:100%;background-color:#f44336; /* Green */border: none;color: white;" value="Pending">
    </form>
    </td>
  </tr>

  
   <?php } ?>

   <?php
  
   $storeid=$_REQUEST['storeid'];
   $sql5="SELECT * FROM tbl_order WHERE storeid='$storeid' AND orderstatus='Delivered'";
   $result5=mysqli_query($con,$sql5);
   while($row5=mysqli_fetch_array($result5))
   {
 ?>
<tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row5['date']?></td>
    
    <td style="color:#4CAF50"><?php echo $row5['u_id']?></td>
    <td><?php echo $row5['address']?></td>
    <td style="color:#4CAF50"><?php echo $row5['phone']?></td>
    <td><?php echo $row5['postcode']?></td>
    <td style="color:#4CAF50"><?php echo $row5['status']?></td>
    <td style="width:60px;"><input type="text" style="width:50px;border:none" readonly placeholder="✔✔✔✔"></td>
    <td style="color:#4CAF50">₹<?php echo $row5['total']?></td>
    
    <td style="background:#4CAF50;border:solid;color:WHITE;" id="click">
    <form action="storeapprovedelivery.php" method="post">
    <input type="hidden" name="odrid" value="<?php echo $row5['ord_id']?>">
    <input type="hidden" name="storeid" value="<?php echo $storeid; ?>">
    <input type="submit" disabled style="margin-top:10px; background-color:#4CAF50;border: none  ;color: white;" value="Delivered">
    </form>
    </td>
  </tr>

 <?php }?>
 
  <input class="btn btn-info btn-lg w3-hover-white w3-card" data-toggle="modal" data-target="#category"style="width:180px;height:50px;background:teal;border:none;margin-top:10px;float:right;" class="w3-panel w3-card " type="button" value="Daily Report"><br>
<!-- Modal -->
<div class="modal fade" id="category" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <br>
         
        </div>
        <div  class="modal-body">
        
        <div id="report">
       
        <h3>Daily Report:<?php 
        echo$date=date("d/m/Y");?></h3>
        <div id="piechart"></div>

      


        <?php 
        $date=date("d/m/Y");
        $sql11="SELECT * FROM  tbl_order WHERE date='$date'";
        $result11=mysqli_query($con,$sql11);
        $c=1;
        while($row11=mysqli_fetch_array($result11))
        {
         ?>
          <h4>Report Id:<?php echo $c;?></h4>
         <ul class="w3-ul w3-border">
         <li><b>Order Number</b>::<?php echo $row11['ordernumber']; ?></li>
         <li><b>User</b>::<?php echo $row11['u_id']; ?></li>
         <li><b>Mobile</b>::<?php echo $row11['phone']; ?></li>
         <li><b>Products</b>::<?php echo $row11['pr_namelist']; ?></li>
         <li><b>Total Amount</b>::<?php echo $row11['total']; ?></li>
         <li><b>Payment Status</b>::<?php echo $row11['status'];  ?></li>
         <li><b>Transaction id</b>::<?php echo $row11['transactionid'];  ?></li>
         </ul>
        <?php $c++;} ?>
        </div>
  <p><input type="button" onclick="dailyreport()" class="w3-btn w3-teal" value="Download"></p>
         </div>
        <div class="modal-footer">
          <button type="button"  data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
 <table>

<tr>
    <th style="width:20px;">&nbsp;OrderDate</th>
    
    <th style="background:#D3D3D3">User</th>
    <th>Account Number</th>
    <th style="background:#D3D3D3">Phone</th>
    <th>IFSC</th>
    <th style="background:#D3D3D3">Payment</th>
    
    <th style="background:#D3D3D3">Total Amount</th>
    
    <th>Cancellation</th>
   <?php
  
   $storeid=$_REQUEST['storeid'];
   $sql5="SELECT * FROM tbl_order WHERE storeid='$storeid' AND orderstatus='cancelled'";
   $result5=mysqli_query($con,$sql5);
   while($row5=mysqli_fetch_array($result5))
   {
 ?>


  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row5['date']?></td>
    <td style="color:#f44336"><?php echo $row5['u_id']?></td>
    <td><?php echo $row5['Account Number']?></td>
    <td style="color:#f44336"><?php echo $row5['phone']?></td>
    <td><?php echo $row5['IFSC']?></td>
    <td style="color:#f44336"><?php echo $row5['status']?></td>
    <form action="storerefund.php" method="post">
    
    <td style="color:#f44336">₹<?php echo $row5['total']?></td>
    
    <td style="background:#f44336;border:solid;color:WHITE;"id="click">
    
    <input type="hidden" name="odrid" value="<?php echo $row5['ord_id']?>">
    <input type="hidden" name="storeid" value="<?php echo $storeid; ?>">
    <input type="submit" style="margin-top:10px;height:100%;width:100%;background-color:#f44336; /* Green */border: none;color: white;" value="<?php echo $row5['orderstatus'] ?>">
    </form>
    </td>
  </tr>

  
   <?php } ?>

   <?php
  
  $storeid=$_REQUEST['storeid'];
  $sql5="SELECT * FROM tbl_order WHERE storeid='$storeid' AND orderstatus='Refunded'";
  $result5=mysqli_query($con,$sql5);
  while($row5=mysqli_fetch_array($result5))
  {
?>


 <tr>
   <td>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row5['date']?></td>
   <td style="color:DodgerBlue"><?php echo $row5['u_id']?></td>
   <td><?php echo $row5['Account Number']?></td>
   <td style="color:DodgerBlue"><?php echo $row5['phone']?></td>
   <td><?php echo $row5['IFSC']?></td>
   <td style="color:DodgerBlue"><?php echo $row5['status']?></td>
   <form action="storerefund.php" method="post">
   
   <td style="color:DodgerBlue">₹<?php echo $row5['total']?></td>
   
   <td style="background:DodgerBlue;border:solid;color:WHITE;"id="click">
   
   <input type="hidden" name="odrid" value="<?php echo $row5['ord_id']?>">
   <input type="hidden" name="storeid" value="<?php echo $storeid; ?>">
   <input type="submit" style="margin-top:10px;height:100%;width:100%;background-color:DodgerBlue;border: none;color: white;" value="<?php echo $row5['orderstatus'] ?>">
   </form>
   </td>
 </tr>

 
  <?php } ?>
   
   </table>
   
      
    
   </div>
   
  

   <script>
   
   function dailyreport() {
        var sTable = document.getElementById('report').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 17px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CREATE A WINDOW OBJECT.
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>Profile</title>');   // <title> FOR PDF HEADER.
        win.document.write(style);          // ADD STYLE INSIDE THE HEAD TAG.
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(sTable);         // THE TABLE CONTENTS INSIDE THE BODY TAG.
        win.document.write('</body></html>');

        win.document.close(); 	// CLOSE THE CURRENT WINDOW.

        win.print();    // PRINT THE CONTENTS.
    }
   
</script>
<?php $var="1000"; ?>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
  var data = google.visualization.arrayToDataTable([
  ['Task', 'Hours per Day'],
  [' Groceries',<?php echo $var ?>],
  [' Household', 2000],
  [' Personal Care', 4000],
  [' Beverages', 2000],
  [' Others', 8000]
]);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'Products sold', 'width':550, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>
   
   <?php include("storefooter.php");?>
<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>