<?php
include("../dbconnection.php");
$storeid=$_REQUEST['storeid'];
$pr_id=$_REQUEST['prid'];
$sql="UPDATE tbl_products SET pr_status='Not Available' WHERE pr_storeid='$storeid' AND pr_id='$pr_id'";
$result=mysqli_query($con,$sql);
header("location:store_total_products.php?storeid=$storeid");
?>