<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");

?>


<div class="container">
<style>
#myInput {
  /* background-image: url('../images/searchicon.png'); */
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 16px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 6px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
<hr>
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name">

<table id="myTable">
  <tr class="header">
    <th style="width:20%;">Name</th>
    <th style="width:10%;">ID</th>
    <th style="width:35%;">Universal Product Code</th>
    <th style="width:25%;">Required</th>
    <th style="width:10%;">In Stock</th>
    <th style="width:5%;">New Stock</th>
    <th style="width:25%;">Add Stock</th>
  </tr>
 

  <?php
  
   $storeid=$_REQUEST['storeid'];
   $sql5="SELECT * FROM tbl_products WHERE pr_storeid='$storeid' AND pr_status='Available' AND pr_requantity>=instock ORDER BY instock ASC";
   $result5=mysqli_query($con,$sql5);
   while($row5=mysqli_fetch_array($result5))
   {
      
 ?>
  <form action="store_add_stock.php?storeid=<?php echo $storeid ?>&prid=<?php echo $row5['pr_id'];?>" method="POST">
  <tr>
    <td style="color:#f44336;"><?php echo $row5['pr_name'] ?></td>
    <td style="color:#f44336;"><?php echo $row5['pr_id'] ?></td>
    <td style="color:#f44336;"><?php echo $row5['upc'] ?></td>
    <td style="color:#f44336;"><?php echo $row5['pr_requantity'] ?></td>
    <td><input style="border:none;color:RED;" name="instock" type="text" readonly placeholder="Enter Stock" value="<?php echo $row5['instock'] ?>"></td>
    <td><input style="border:none;" name="newstock" required="" type="text" placeholder="Enter Stock"></td>
    <td style="background:#f44336"><input type="submit"style="width:100%;background-color:#f44336;border: none;color: white;" value="Add to Stock" ></td>
  </tr>
  </form>
  <?php } ?>
  <?php
  
  $storeid=$_REQUEST['storeid'];
  $sql5="SELECT * FROM tbl_products WHERE pr_storeid='$storeid' AND pr_status='Available' AND pr_requantity<instock ORDER BY instock ASC";
  $result5=mysqli_query($con,$sql5);
  while($row5=mysqli_fetch_array($result5))
  {
     
?>
 <form action="store_add_stock.php?storeid=<?php echo $storeid ?>&prid=<?php echo $row5['pr_id'];?>" method="POST">
 <tr>
   <td><?php echo $row5['pr_name'] ?></td>
   <td><?php echo $row5['pr_id'] ?></td>
   <td><?php echo $row5['upc'] ?></td>
   <td><?php echo $row5['pr_requantity'] ?></td>
   <td><input style="border:none;" name="instock" type="text" readonly placeholder="Enter Stock" value="<?php echo $row5['instock'] ?>"></td>
   <td><input style="border:none;" name="newstock" required="" type="text" placeholder="Enter Stock"></td>
   <td style="background:#4CAF50"> <input type="submit"style="width:100%; background-color: #4CAF50;border: none;color: white;" value="Add to Stock" ></td>
 </tr>
 </form>
 <?php } ?>
</table>
<hr>
</div>

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

<?php include("storefooter.php");?>
<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>