<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");

?>
<style>
body {
 background-image: url("../images/qstore.jpg");
 background-color: #cccccc;
}
</style>
<script>
    function dist()
    {
        var district=document.getElementById('district').value;
       
        var data=new FormData();
        data.append('did',district);

        $.ajax({
            method:'post',
            url:"districtaction.php",
            processData: false,
            contentType:false,
            data: data,
            success:function(result){
            // alert(result);
             var r=JSON.parse(result);
             $('#city').html("<option value=0>"+"select City"+"</option>");

             for(i=0;i<r.length;i++){
             $('#city').append("<option value="+r[i].id+">"+r[i].value+"</option")
             }
            }
        })

    }
</script>

<div class="register " >
		<div class="container">
			
			<div style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
                         margin: auto;
                         text-align: center;
                         font-family: arial;"class="login-form-grids">
                         <h2>Add Store</h2>
				<h5>Store information</h5>
				<form action="addstoreaction.php" onsubmit="return" class="oh-autoval-form" method="post" enctype="multipart/form-data">
                    <input type="text" class="av-name" av-message="Minimum 3 characters and alphabets only" name="sname" placeholder="Store Name" required=" ">
					<input type="text" class="av-name" av-message="Enter Location" name="slocation" placeholder="Location" required=" ">
                    <input type="hidden" name="useremail" value="<?php echo $u_id; ?>">
					<input type="text" class="av-pincode" av-message="Enter Pincode" name="spincode" placeholder="Pincode" required=" "></br>
					<textarea style="width:417px;" name="landmark" placeholder="Landmark" required=" "></textarea>
                    <h6>License/Registration No</h6>
                    <input type="text" name="license" class="av-atm" av-message="Enter a valid fssai number" placeholder="Enter 14 digit fssai Number" required=" ">
                    <h6>Other information</h6>
                    

                <select id="district" name="district" style="outline: none;border: 1px solid #DBDBDB;padding: 10px 10px 10px 10px;font-size: 14px;color: #999;display: block;width: 100%;"  required="" onchange="return dist()">
                    <option value="0">District</option>
                    <?php 
                    include("../dbconnection.php");
                    $sql="SELECT * FROM tbl_district";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    {
                        $id=$row['distid'];
                        $name=$row['dname'];
                        ?>
                        
                        <option value='<?php echo $id ?>'><?php echo $name ?></option>";
                        <?php
                    }
                    ?>
                    </select>
                    </br>
                    <select name="city" id="city"  style="outline: none;border: 1px solid #DBDBDB;padding: 10px 10px 10px 10px;font-size: 14px;color: #999;display: block;width: 100%;"  required="">
                    <option value="0">City</option>
					
                    </select>
                    <h6>Delivery Options</h6>
                    <select name="delivery" id="delivery"  style="outline: none;border: 1px solid #DBDBDB;padding: 10px 10px 10px 10px;font-size: 14px;color: #999;display: block;width: 100%;"  required="">
                    <option value="notavailable">Not Available</option>
					<option value="available">Available</option>
					
                    </select></br>
                    <input type="text" name="shippingcost"  placeholder="Enter Shipping Cost">
                    <h6>Add Image</h6>
					<input type="file" class="av-image" av-message="Please select a Valid Image." name="photo" id="photo">
					
					<input type="submit" value="Add Store">
				</form>
			</div>
			
		</div>
	</div>            
<?php include("storefooter.php");?>
<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>