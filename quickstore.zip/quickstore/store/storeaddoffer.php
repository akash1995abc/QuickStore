<?php 
include("../dbconnection.php");
$storeid=$_REQUEST['storeid'];
$date=date("Y/m/d");
$fileimage = time().$_FILES['photo']['name'];
move_uploaded_file($_FILES['photo']['tmp_name'],"../images/".$fileimage);
$sql="INSERT INTO tbl_offers VALUES(null,'$storeid','$fileimage','$date','valid')";
$result=mysqli_query($con,$sql);
header("location:offerzone.php?msg=inserted&storeid=$storeid");

?>