
<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");
?>

<?php
                $storeid=$_POST["storeid"];
				$sql="SELECT * FROM tbl_store where storeid='$storeid'";
				$result=mysqli_query($con,$sql);
				while($row=mysqli_fetch_array($result))
				{
				?>
<style>
body {
 background-image: url("../images/qstore.jpg");
 background-color: #cccccc;
}
</style>
				<div class="register " >
		<div class="container">
			<center><h2 style="background-color:WHITE;width:510px;">Edit Store</h2></center>
			<div style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
                         margin: auto;
                         text-align: center;
                         font-family: arial;"class="login-form-grids">
				<h5>Store information</h5>
				<form action="editstoreaction.php" onsubmit="return" class="oh-autoval-form" method="post" enctype="multipart/form-data">
                    <input type="text" class="av-name" av-message="Minimum 3 characters and alphabets only" name="sname" placeholder="Store Name" value="<?php echo $row['sname'] ?>"></br>
					<input type="hidden" name="storeid" value="<?php echo $row['storeid']; ?>">
					
					<textarea style="width:417px;" name="map" placeholder="Embed Map" required="" value="nil"></textarea>
                    <h6>Delivery Options</h6>
                    <select name="delivery" id="delivery"  style="outline: none;border: 1px solid #DBDBDB;padding: 10px 10px 10px 10px;font-size: 14px;color: #999;display: block;width: 100%;"  required="">
                    <option value="notavailable">Not Available</option>
					<option value="available">Available</option>
					
                    </select></br>
                    <input type="text" name="shippingcost" value="<?php echo $row['shippingcost'] ?>"  placeholder="Enter Shipping Cost">
                    <h6>Add Image</h6>
					<input type="file" class="av-image" av-message="Please select a Valid Image." name="photo" id="photo">
					
					<input type="submit" value="Edit details">
				</form>
			</div>
			
		</div>
	</div>  



                <?php } ?>
<?php include("storefooter.php");?>
<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>