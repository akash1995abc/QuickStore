
<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("storeheader.php");

?>



<?php
				$sql="SELECT * FROM tbl_store WHERE useremail='$u_id'";
				$result=mysqli_query($con,$sql);
				$count=mysqli_num_rows($result);
				?>
				<div class="w3-container">
  <div class="w3-panel w3-pale-blue w3-leftbar w3-rightbar w3-border-blue">
      <center>	<h3>WELCOME TO QUICKSTORE </h3>
				</center>
  </div>
</div>
			  <?php


				while($row=mysqli_fetch_array($result))
				{
				?>
				
<style>
.label {
  color: white;
  padding: 8px;
  font-family: Arial;
}
.success {background-color: #4CAF50;} /* Green */
.warning {background-color: #ff9800;} /* Orange */
.danger {background-color: #f44336;} /* Red */ 
.other {background-color: #e7e7e7; color: black;} /* Gray */ 
</style>				
			

			<style>
body {
 
 background-color: #FFFFF;
}
</style>




<div  class="products">
		<div  class="w3-panel w3-card-2 container">
		<header style="margin-top:10px;background-color:#333;" class="w3-card-4 w3-container">
      <h1 style="color:#FFFF;"><?php echo $row['sname'] ?> SuperMarket</h1>
			</header>
	
			<table class="w3-container w3-center">
			<tr>
			<td style="width:33%;"><img class="w3-left-align w3-panel " src="../images/<?php echo $row['simage'] ?>" style="width:300px;height:280px;"></td>
			
			<td class="w3-panel w3-card-2" style="width:33%;">
			
			<button class="like" readonly style="border:none;background:WHITE;color:#3399ff;" onclick="likestore('<?php echo $row['storeid'];?>','<?php echo $u_id ?>')">
  <span class="fa fa-thumbs-up fa-2x"></span>Likes
  <?php 
  $storeid=$row['storeid'];
  $sql1="SELECT * FROM tbl_like WHERE storeid='$storeid' AND action='like'";
  $result1=mysqli_query($con,$sql1);
  echo $count=mysqli_num_rows($result1);
  ?>
  </button>
  <button class="dislike" readonly style="border:none;background:WHITE;color:#ff3333;float:right; " onclick="dislikestore('<?php echo $row['storeid'];?>','<?php echo $u_id ?>');">
    <span class="fa fa-thumbs-down fa-2x"></span>Dislikes
	<?php 
  $storeid=$row['storeid'];
  $sql1="SELECT * FROM tbl_like WHERE storeid='$storeid' AND action='dislike'";
  $result1=mysqli_query($con,$sql1);
  echo $count=mysqli_num_rows($result1);
  ?>
  </button>
			<h4><b>Landmark </b>:<?php echo $row['slandmark'] ?></h4>
			
			<h4><b><i class="glyphicon glyphicon glyphicon-ok" aria-hidden="true"></i>&nbsp;License Number</b> :<?php echo $row['slicense'] ?></h4>

			<h4><b><i class="glyphicon glyphicon glyphicon-ok" aria-hidden="true"></i>&nbsp;Pincode </b>:<?php echo $row['spincode'] ?>
			<h4><b>Available Products</b></h4>


        <?php
				$sql8="SELECT * FROM tbl_category";
				$result8=mysqli_query($con,$sql8);
				while($row8=mysqli_fetch_array($result8))
				{
				?>
			<div style="display: inline-block; padding: 0 10px; height: 20px;font-size: 12px; line-height: 20px;border-radius: 25px; background-color: #f1f1f1;margin-bottom:5px;margin-right:5px;" class="chip">
			<i class="fa fa-check-square" aria-hidden="true"></i>
      <?php echo $row8['catname'] ?>
      </div>
				<?php } ?>
<!--  -->
		  </td>
    
			<td style="width:33%;">
					<?php 
					
					$storeid=$row['storeid'];
					$sql5="SELECT * FROM tbl_products WHERE pr_storeid='$storeid'";
					$result5=mysqli_query($con,$sql5);
					$count5=mysqli_num_rows($result5);

					?>
	        <button onclick="store_view_total_products(<?php echo $storeid; ?>);" style="height:40px;width:300px;border:none" class="w3-panel w3-card-2 w3-green w3-hover-orange" value="Total Products">Total Products<span class="w3-badge w3-margin-left w3-white"><?php echo $count5; ?></span>
			</button></br>
			<?php 
					$storeid=$row['storeid'];
					$sql9="SELECT * FROM tbl_products WHERE pr_storeid='$storeid' AND instock<=pr_requantity AND pr_status='Available'";
					$result9=mysqli_query($con,$sql9);
					$count9=mysqli_num_rows($result9);

					?>
	        <button onclick="store_view_lowstock(<?php echo $storeid; ?>);" style="height:40px;width:300px;border:none" class="w3-panel w3-card-2 w3-red w3-hover-orange" value="Total Products">Low Stock<span class="w3-badge w3-margin-left w3-white"><?php echo $count9; ?></span>
			</button></br>
	

			<?php 
					$storeid=$row['storeid'];
					$sql6="SELECT * FROM tbl_order WHERE storeid='$storeid'";
					$result6=mysqli_query($con,$sql6);
					$count6=mysqli_num_rows($result6);

					?>
	        <button onclick="store_view_orders(<?php echo $storeid; ?>);" style="height:40px;width:300px;border:none" class="w3-panel w3-card-2 w3-blue w3-hover-orange"" value="Total orders">Total Orders<span class="w3-badge w3-margin-left w3-white"><?php echo $count6; ?></span>
			</button>

			<?php 
					$storeid=$row['storeid'];
					$sql60="SELECT * FROM tbl_feedback WHERE storeid='$storeid'";
					$result60=mysqli_query($con,$sql60);
					$count60=mysqli_num_rows($result60);

					?>
	        <button onclick="store_view_feedback(<?php echo $storeid; ?>);" style="height:40px;width:300px;border:none" class="w3-panel w3-card-2 w3-indigo w3-hover-orange"" value="feedback">View Feedback<span class="w3-badge w3-margin-left w3-white"><?php echo $count60; ?></span>
			</button>
			
	    
	 	</table>			
				
			</td>
      </tr>
			</table>
			
    <footer style="margin-bottom:10px;background-color:#333;" class="w3-container w3-card-4">
			<!-- <h5 style="color:#FFFF;">Footer</h5> -->
			<!-- button below -->
			
			<div class="w3-bar">
<form  action="edit_store.php" method="post" class="w3-bar-item">
		<input type="hidden" name="storeid" value="<?php echo $row['storeid']; ?>">
		<input   type="submit"  name="submit" value="Edit Store" class="w3-hover-amber"
		style="background-color: WHITE;border: none;color: #333;padding: 10px 32px;width:310px;
					text-align: center;text-decoration: none;display: inline-block;font-size: 16px;cursor: pointer;">
							</form>
<form  action="storeproducts.php" method="post" class="w3-bar-item">
		<input  type="hidden" name="storeid" value="<?php echo $row['storeid']; ?>">
		<input  type="submit" name="submit" value=" Edit Products"class="w3-hover-amber"
		style="background-color: WHITE;border: none;color: #333;padding: 10px 32px;	text-align: center;
	         text-decoration: none;display: inline-block;font-size: 16px;cursor: pointer;width:310px;margin-left:40px;" >
							</form>
<form  action="offerzone.php?storeid=<?php echo $storeid;?>" method="post" class="w3-bar-item">
		<input  type="hidden" name="storeid" value="<?php echo $row['storeid']; ?>">
		<input  type="submit" name="submit" value="Ads Zone"class="w3-hover-amber"
		style="background-color: WHITE;border: none;color: #333;padding: 10px 32px;	text-align: center;
	         text-decoration: none;display: inline-block;font-size: 16px;cursor: pointer;width:310px;margin-left:40px;" >
							</form>


				</div>
    </footer>
  <!-- </div> -->
		</div>
	</div>   
    
	<?php }  ?>

	<script type="text/javascript">
    function store_view_orders(s) {
			// console.log(s);
			  location.href = "store_view_orders.php?storeid="+s;
    };
    function store_view_total_products(s) {
        location.href = "store_total_products.php?storeid="+s;
    };
    function store_view_lowstock(s) {
        location.href = "store_view_lowstock.php?storeid="+s;
    };
    function store_view_feedback(s) {
        location.href = "store_view_feedback.php?storeid="+s;
    };
</script>




	<script>
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>
<?php include("storefooter.php");?>


<?php
 }
else
{
	header("location:../login.php?loginfirst");
}

?>




