<?php 
include("../dbconnection.php");
$storeid=$_POST['storeid'];
$sname=$_POST['ename'];
$slocation=$_POST['location'];
$spincode=$_POST['pincode'];
$slandmark=$_POST['landmark'];
$license=$_POST['slicense'];
$useremail=$_POST['usermail'];
$city=$_POST['city'];
$map=$_POST['map'];

// $photo= time().$_FILES['photo']['name'];
// move_uploaded_file($_FILES['photo']['tmp_name'],"../images/".$photo);

$sql="UPDATE tbl_store SET sname='$sname', spincode='$spincode', slandmark='$slandmark', map='$map' WHERE useremail='$useremail' AND storeid='$storeid'";
$result=mysqli_query($con,$sql);

header("location:store_home.php?text=Store Updated");
?>