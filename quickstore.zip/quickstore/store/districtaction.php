<?php

 include("../dbconnection.php");
$city=array();
$i=0;

$cid=$_POST['did'];
$sql="SELECT * FROM tbl_city WHERE distid='$cid' ";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    {
                        $id=$row['cityid'];
                        $name=$row['cname'];
                        $city[$i]['id']=$id;
                        $city[$i]['value']=$name;
                        $i++;
                      
                    }
     echo json_encode($city);
     ?>