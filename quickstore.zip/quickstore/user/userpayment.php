
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link href="../css/oh-autoval-style.css" rel="stylesheet" type="text/css" media="all" />
<script src="../js/oh-autoval-script.js"></script>
<script src="../js/jquery.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 700px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
<style>
body {
 background-image: url("../images/qstore.jpg");
 background-color: #cccccc;
}

</style>
</head>
<body>
<?php
$quantity=$_REQUEST['quantity'];

$storeid=$_REQUEST['storeid'];

$pname=$_REQUEST['pname'];
$pid=$_REQUEST['pid'];

$price=$_REQUEST['price'];
$uid=$_REQUEST['uid'];
if(isset($_POST['phone'])){

  $phone=$_REQUEST['phone'];
  
}else
{
  $phone="Offline PickUp";
}
if(isset($_POST['pincode'])){

  $postcode=$_REQUEST['pincode'];

}else
{
  $postcode="Offline PickUp";
}
if(isset($_POST['address'])){

  $address=$_REQUEST['address'];

}else
{
  $address="Offline PickUp";
}


   $total=$_REQUEST['total'];
?>

<div class="row">
  <div class="col-50">
    <div style="width:50%;margin-left:25%;"  class="w3-panel w3-card-4 container">
      <form action="placeorder.php" onsubmit="return" class="oh-autoval-form" method="post">
      <input type="hidden" name="quantity" value="<?php echo $quantity ?>">
      <input type="hidden" name="storeid" value="<?php echo $storeid ?>">
      <input type="hidden" name="pname" value="<?php echo $pname ?>">
      <input type="hidden" name="pid" value="<?php echo $pid ?>">
      <input type="hidden" name="price" value="<?php echo $price ?>">
      <input type="hidden" name="uid" value="<?php echo $uid ?>">
      <input type="hidden" name="phone" value="<?php echo $phone ?>">
      <input type="hidden" name="pincode" value="<?php echo $postcode ?>">
      <input type="hidden" name="address" value="<?php echo $address ?>">
      <input type="text" style="border:none;" name="total" readonly value="<?php echo $total ?>">
      
        

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" pattern="^[a-zA-Z]+$" id="cname" name="cardname" required value="John More Doe">
            <label for="ccnum">Enter card number</label>
            <input type="text"  class="av-atm" av-message="Enter a valid card number" required name="cardnumber" value="5424753256789010">
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" required value="april">
           
            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" required value="2020">
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" value="023" required class="av-positive" av-message="Enter a valid cvv">
              </div>
            </div>
          </div>
        </div>
        <input type="submit" style="width:50%;margin-left:25%;margin-top:-10px;" value="Continue to checkout" class="btn w3-panel w3-card">
      </form>
</div>
</body>
</html>

   
   