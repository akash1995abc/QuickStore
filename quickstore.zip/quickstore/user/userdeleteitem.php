<?php
include("../dbconnection.php");
$prid=$_REQUEST['productid'];
$storeid=$_REQUEST['storeid'];
$cvalue=$_REQUEST['cvalue'];
// echo $prid;
// echo $storeid;
// echo $cvalue;
$sql="DELETE FROM tbl_basket WHERE pr_id='$prid' AND storeid='$storeid'";
$result=mysqli_query($con,$sql);


?>