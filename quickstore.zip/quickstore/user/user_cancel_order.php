<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("userheader.php");

?>
<?php
 $orderid=$_REQUEST['orderid'];
 $total=$_REQUEST['total'];
 $pridlist=$_REQUEST['pridlist'];
 $prqtylist=$_REQUEST['prqtylist'];

    
?>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="http://digitalbush.com/wp-content/uploads/2013/01/jquery.maskedinput-1.3.1.min_.js"></script>
 <script type='text/javascript'>
    $(function(){
        // Define your mask (4 letters explicitly)
        $('#YourTextBox').mask('9999');
    });
  </script>
<div align="center"class="container">
<form style="margin-top:20px;margin-bottom:20px;width:50%;display:center;"class="w3-container w3-card-4" action="ordercancel.php" method="POST">
  <h2>Select Reason for Cancellation</h2>

  <select class="w3-select w3-border" name="option">
    <option value="" disabled selected>Choose your option</option>
    <option value="1">You come across with better deal on the same product which you ordered</option>
    <option value="2">Option 2</option>
    <option value="3">Not Specified</option>
  </select>
  <br><br>
  <input type="hidden" name="total" value="<?php echo $total ?>">
  <input type="hidden" name="orderid" value="<?php echo $orderid ?>">
  <input type="hidden" name="pridlist" value="<?php echo$pridlist?>">
  <input type="hidden" name="prqtylist" value="<?php echo$prqtylist ?>">
  <h5>Refund Information</h5>
  <input type="text" name="ifsc" placeholder="Enter IFSC" required="">
  <br>
  <br>
  <p><input type="submit" class="w3-btn w3-teal"value="Cancel Order!"></p>
  <br>

</form>
</div>
<?php include("userfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?login");
}

?>