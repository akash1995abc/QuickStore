<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("userheader.php");

?>
<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="user_home.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Our Products</li>
				<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Category<b class="caret"></b></a>
										<ul class="dropdown-menu multi-column columns-3">
											<div class="row">
												<div class="multi-gd-img">
													<ul class="multi-column-dropdown">
														<h6 style="font-size:15px;">Category</h6>
														<li><a href="user_view_products.php">All</a></li>
														<?php 
                    include("../dbconnection.php");
                    $sql="SELECT * FROM tbl_category";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    { ?>
					<li><a href="user_view_products.php?cati=<?php echo $row['catid'] ?>"><?php echo $row['catname'] ?></a></li>
														
					<?php
					}
					?>								
													</ul>
												</div>
												
												
											</div>
										</ul>
									</li>


									
			</ol>

		</div>
	</div>
	
    <div class="products">

	
<div class="container">
<div class="products-right-grids">
						
						
						
						
						
						<div class="clearfix"> </div>
					</div>
<?php 
					include("../dbconnection.php");
					
					
					if(isset($_GET['cati']))
				{
						$catid= ($_GET['cati']);
						
					$sql="SELECT * FROM tbl_subcategory WHERE catid='$catid'";
					$result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_array($result))
					{     $subcatid=$row['subcatid'];        
					$sql1="SELECT * FROM tbl_products WHERE pr_subcatid='$subcatid'";
					$t=mysqli_query($con,$sql1);
					$total=mysqli_num_rows($t);
					$start=0;
					$limit=12;
					if(isset($_GET['id']))
					{
					   $id=$_GET['id'];
					   $start=($id-1)*$limit;
					}else
					{
						$id=1;				
					}
					$page=ceil($total/$limit);
                    $result2=mysqli_query($con,$sql1);
                    while($row1=mysqli_fetch_array($result2))
                    {
?>		


									
<div style="margin-bottom:5px;width:280px;" class="col-md-4 top_brand_left">
									<div style="border-radius:10px" class="w3-panel w3-card-4 hover14 column">
										<div class="agile_top_brand_left_grid">
											<div class="agile_top_brand_left_grid_pos">
												<img src="../images/offer.png" alt=" " class="img-responsive">
											</div>
											<div class="agile_top_brand_right_grid_pos">
		<a href=""><img style="width:20px;" onclick="myFunction(this)" src="../images/wsh.png" alt=" " class="img-responsive"></a>
	
		</div>
											<div class="agile_top_brand_left_grid1">
												<figure>
													<div class="snipcart-item block">
											<div class="snipcart-thumb">
								<a href="products.php"><img style="width:160px;height:160px;" title=" " alt=" " src="../images/<?php echo $row1['pr_image'];?>"></a>		
															<p><?php echo $row1['pr_name']?></p>
														
															<h4>₹<?php echo $row1['pr_cost']?>.00<span>₹<?php echo $row1['pr_actcost']?>.00</span></h4>
														</div>
														<div class="snipcart-details top_brand_home_details">
															<form action="login.php">
															<input type="submit" name="submit" value="Buy Now" class="button">
															</form>
														</div>
													</div>
												</figure>
											</div>
										</div>
									</div>
								</div>

									<?php
					                } 
									} 
								}
					else{
						$sql2="SELECT * FROM tbl_products";
						$t=mysqli_query($con,$sql2);
						$total=mysqli_num_rows($t);
						$start=0;
						$limit=12;
						if(isset($_GET['id']))
						{
						   $id=$_GET['id'];
						   $start=($id-1)*$limit;
						}else
						{
							$id=1;				
						}
						$page=ceil($total/$limit);
						$sql2="SELECT * FROM tbl_products LIMIT $start,$limit";
						$result3=mysqli_query($con,$sql2);
						while($row1=mysqli_fetch_array($result3))
					{
		                ?>
						<div style="margin-bottom:5px;width:280px;" class="col-md-4 top_brand_left">
									<div style="border-radius:10px" class="w3-panel w3-card-4 hover14 column">
										<div class="agile_top_brand_left_grid">
											<div class="agile_top_brand_left_grid_pos">
												<img src="../images/offer.png" alt=" " class="img-responsive">
											</div>
											<div class="agile_top_brand_right_grid_pos">
		<a href=""><img style="width:20px;" src="../images/wsh.png" alt=" " class="img-responsive"></a>
	
		</div>
											<div class="agile_top_brand_left_grid1">
												<figure>
													<div class="snipcart-item block">
											<div class="snipcart-thumb">
					<a href="products.php"><img style="width:160px;height:160px;" title=" " alt=" " src="../images/<?php echo $row1['pr_image'];?>"></a>		
							<p><?php echo $row1['pr_name']?></p>
														
							<h4>₹<?php echo $row1['pr_cost']?>.00<span>₹<?php echo $row1['pr_actcost']?>.00</span></h4>
							<p style="color:INDIGO"><?php echo $row1['instock']?>-Left in Stock.</p>
							</div>
							<div class="snipcart-details top_brand_home_details">
							<form action="user_select_store.php" method="POST">
                            <input type="hidden" name="storeid" value="<?php echo $row1['pr_storeid']?>">
                            
							<input type="submit" name="submit" value="Buy Now" class="button">

							</form>
												</div>
													</div>
												</figure>
											</div>
										</div>
									</div>
								</div>
								<?php
								}
					}
									?>
                                        </div>
									
										<nav style="text-align: center;"class="numbering">
					<ul class="pagination paging">
					<?php
					if($id > 1){
					?>
					<li class="active"><a href="?id=<?php echo ($id-1); ?>" aria-label="Previous">
								<span aria-hidden="true">Previous<<</span>                               
								<!-- class="active"
								<span class="sr-only">(current)</span> -->
						</a></li>
					<?php } ?>
					<?php for($i=1;$i <=$page;$i++)
					{ 
					?>
						<li><a href="?id=<?php echo $i ; ?>"><?php echo $i ?></a></li>
					<?php
					}
					?>
						<?php 
						if($id!=$page)
						{
						?>
					    <li class="active">
							<a href="?id=<?php echo ($id+1); ?>" aria-label="Next">
							<span aria-hidden="true">Next>></span>
							</a>
						</li>
						<?php }?>
					</ul>
				</nav>
                                        </div>

           <?php include("userfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?login");
}

?>
