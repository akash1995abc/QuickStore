<?php
include("../dbconnection.php");
//get search term
$searchTerm = $_GET['term'];
//get matched data from skills table
$query = $con->query("SELECT * FROM tbl_products WHERE pr_name LIKE '%".$searchTerm."%' ORDER BY pr_name ASC");
while ($row = $query->fetch_assoc()) {
    $data[] = $row['pr_name'];
}
//return json data
echo json_encode($data);
?>