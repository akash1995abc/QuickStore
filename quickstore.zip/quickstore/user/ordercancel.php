<?php 
include("../dbconnection.php");
 $total=$_REQUEST['total'];
 $pridlist=$_REQUEST['pridlist'];
 $prqtylist=$_REQUEST['prqtylist'];
 $orderid=$_REQUEST['orderid'];
 $ifsc=$_REQUEST['ifsc'];
    $quantitys=explode(',',$prqtylist);
    $pids=explode(',',$pridlist);
    for($i=1;$i<sizeof($pids);$i++)
    {    
        $sql11="SELECT * FROM tbl_products WHERE pr_id='$pids[$i]'";
        $result11=mysqli_query($con,$sql11);
        $row11=mysqli_fetch_array($result11);
        $stock=$row11['instock'];
        $total=$stock+$quantitys[$i];
        mysqli_query($con,"UPDATE tbl_products SET instock='$total' WHERE pr_id='$pids[$i]'");
       
    }
    mysqli_query($con,"UPDATE tbl_order SET orderstatus='cancelled',ifsc='$ifsc' WHERE ord_id='$orderid'");
   header("location:user_view_order.php?text=done!!!");

?>