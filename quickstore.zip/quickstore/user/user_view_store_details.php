<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("userheader.php");

?>


<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Store</a></li>
				<li class="active">information</li>
			</ol>
		</div>
	</div>

<div class="about">

		<div class="w3_agileits_contact_grids">
			<div class="col-md-6 w3_agileits_contact_grid_left">
				<div class="agile_map" style="margin-left:50px;margin-right:-40px">
				<?php $storeid=$_REQUEST['storeid'];
				$sql21="SELECT * FROM tbl_store WHERE storeid='$storeid'";
				$result21=mysqli_query($con,$sql21);
				$row=mysqli_fetch_array($result21);
			  echo $row['map'];
				?>
				</div>
				
			</div>
			<div class="col-md-6 w3_agileits_contact_grid_right">
		
				<h2 style="font-weight:50px;"class="w3_agile_header">Leave a<span> Feedback</span></h2>

				<form action="feebackaction.php" method="post">
					<span class="input input--ichiro">
						<input  type="text" style="outline: none;
						width: 100%;
						background: #f5f5f5;
						color: #212121;	
						padding: 10px;
						font-size: 14px;
						border: 1px solid #e4e4e4;
						font-weight: bold;" id="input-25" name="name" placeholder="Your Name" required="">
						
					</span>
					<?php $storeid=$_REQUEST['storeid']; ?>
					<input type="hidden" value="<?php echo $storeid; ?>" name="storeid">
					<input type="hidden" value="<?php echo $u_id; ?>" name="uid">
					</span>
					<textarea name="message" placeholder="Your message here..." required=""></textarea>
					<input type="submit" value="Submit">
				</form>
			
		
			</div>
			<div class="clearfix"> </div>
			<div class="container">
<?php
  
  $storeid=$_REQUEST['storeid'];
  $sql5="SELECT * FROM tbl_feedback WHERE storeid='$storeid' AND uid='$u_id' AND status='unread'";
  $result5=mysqli_query($con,$sql5);
  while($row5=mysqli_fetch_array($result5))
  {
?>

<div class="w3-card-4" style="width:100%;margin-top:15px;margin-bottom:15px;">
    <header style="height:50px;" class="w3-container">
      <h2><?php echo $row5['name'] ?></h2>
    </header>

    <div class="w3-container">
      <p><?php echo $row5['message'];?></p>
      <p style="color:BLACK;float:right;"><b><?php echo $row5['uid'] ?></b></p>
    </div>

    <footer class="w3-container w3-blue w3-hover-green">
      <h5>Delivered-<?php echo $row5['feeddate'] ?></h5>
			<form action="deletefeedback.php" method="post">
			<input type="hidden" name="feedid" value="<?php echo $row5['feedid'] ?>">
			
			<input type="hidden" name="storeid" value="<?php echo $storeid ?>">

      <input type="submit"onclick="return confirm('Are you sure you want to delete this?')" style="float:right;border:none;color:#333;margin-top:-31px"value="Delete">
         </form>
    </footer>
   </div>
  <?php } ?>
</div>
		</div>
	</div>


<?php include("userfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?login");
}

?>


