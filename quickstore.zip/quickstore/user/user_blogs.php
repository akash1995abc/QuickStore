<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("userheader.php");

?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/oh-autoval-script.js"></script>
<script src="../js/jquery.min.js"></script>
<style>
.zoom {
   transition: transform .2s;
  width: 200px;
  height: 200px;
  margin: 0 auto;
}

.zoom:hover {
  -ms-transform: scale(1.3); /* IE 9 */
  -webkit-transform: scale(1.3); /* Safari 3-8 */
  transform: scale(1.3); 
}
</style>

<div style="padding: 30px;
  font-size: 40px;
  text-align: center;
  background: #FFFFD;">
 <input type="button" id="myBtn" data-toggle="modal" data-target="#district" style="float:right; background-color: #4CAF50;border: none;color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;
  font-size: 16px; margin: 4px 2px;cursor: pointer;" value="Add New Blog">
  <h2 style="color:#D3D3D3;">    .   </h2>
</div>
<?php 
include("../dbconnection.php");
$sql="SELECT * FROM tbl_blogs";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result))
{
?>
    <div style="display: inline-block;margin-left:55px;height:340px;"class="card">
           
      <div style="height:230px;width:262px" >
      <img class="zoom"style="height:230px;width:262px" src="../images/<?php echo $row['photo'] ?>">
      <h4><?php echo $row['b_title']; ?></h4>
      <h5 class="w3-pale-red">Author:<?php echo $row['author']; ?></h5>
      <p class="w3-panel w3-pale-yellow"style="color:INDIGO;margin-top:-10px;">Recipe type:<?php echo $row['type'] ?>.</p>
		
		<p class="w3-panel w3-pale-yellow" style="color:#333;margin-top:-10px;">Serves:<?php echo $row['serves'] ?></p>
	
      <form action="blogdetail.php" method="POST">
      <input type="hidden" name="blogid" value="<?php echo $row['blog_id'] ?>">
      <input type="submit" style="width:100%;border:none;height:30px;background:#333;color:WHITE" value="View Detail"> 
      </form> 
     
      </div>
      
    </div>
<?php } ?>   
<hr>
<!-- Modal -->
<div class="modal fade" id="district" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add New Blog</h4>
        </div>
        <div class="modal-body">
        <div class="panel-body">


<form action="useraddblog.php" method="post" onsubmit="return" class="oh-autoval-form" enctype="multipart/form-data" >
<input class="w3-input w3-border w3-round" required class="av-name" av-message="Minimum 3 Characters and Alphabets only" name="title" placeholder="Blog title"type="text"><br>
<input class="w3-input w3-border w3-round"required name="author" placeholder="Author name"type="text"><br>
<input class="w3-input w3-border w3-round" required name="type" placeholder="Recipe type"type="text"><br>
<input class="w3-input w3-border w3-round" required name="serves" placeholder="Serves"type="text"><br>

<textarea class="w3-input w3-border w3-round"required  name="ingredients" placeholder="Enter ingredients" rows="5" cols="73"></textarea><br>
<textarea class="w3-input w3-border w3-round" required name="content" placeholder="Enter instruction" rows="5" cols="73"></textarea><br>
<input class="w3-input w3-border w3-round" required name="notes" placeholder="Enter notes" type="text"><br>
<input type="file" name="photo">
<input class="w3-input w3-border w3-round" required name="uid" value='<?php echo $u_id;?>' type="hidden"><br>
  <p><input type="submit" style="width:200px;"class="w3-btn w3-teal" value="Save"></p>
 </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <script type="text/javascript">


    $(document).ready(function() {


      $(".add-more").click(function(){ 
          var html = $(".copy").html();
          $(".after-add-more").after(html);
      });


      $("body").on("click",".remove",function(){ 
          $(this).parents(".control-group").remove();
      });


    });


</script>
<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
<script>

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active1");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}
</script>
<?php include("userfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?login");
}

?>
