<?php
include("../dbconnection.php");
 $name=$_REQUEST['name'];
 $message=$_REQUEST['message'];
 $uid=$_REQUEST['uid'];
 $storeid=$_REQUEST['storeid'];
 $date = date('Y/m/d');
$sql="INSERT INTO tbl_feedback VALUES(null,'$name','$message','$uid','$storeid','$date','unread')";
$result=mysqli_query($con,$sql);
if($result)
{
    header("location:user_view_store_details.php?storeid=$storeid&msg=Thanks for your Feedback");
}else
{
    header("location:user_view_store_details.php?storeid=$storeid&msg=Something went Wrong!try again");
}


?>