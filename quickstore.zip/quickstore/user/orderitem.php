<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
  ?><!DOCTYPE html>
<html>
<head>
<title>QuickStore</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Super Market Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="../css/w3.css" rel="stylesheet" type="text/css" media="all" />
<link href="../css/oh-autoval-style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="../css/font-awesome.css" rel="stylesheet"> 

<!-- //font-awesome icons -->
<!-- ajax connection link -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/oh-autoval-script.js"></script>
<script src="../js/jquery.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Raleway:400,100,100italic,200,200italic,300,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->

<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
 ;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
  
}

.card button:hover {
  background-color:#fe9126;
}
input[type=text],textarea{
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
</style>
</head>
<body>
<!-- header -->

	<div style="background-color:#3c2f2f " class="logo_products">
		<div class="container">
		
			<div class="w3ls_logo_products_left">
				<h1><a href="user_home.php">QuickStore</a></h1>
			</div>
		<div class="w3l_search">
			<form action="#" method="post">
				<input type="search" name="Search" placeholder="Search for a Product..." required="">
				<button type="submit" class="btn btn-default search" aria-label="Left Align">
					<i class="fa fa-search" aria-hidden="true"> </i>
				</button>
				<div class="clearfix"></div>
			</form>
		</div>
			
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //header -->
<!-- navigation -->
	<div class="navigation-agileits">
		<div class="container">
			<nav class="navbar navbar-default">
							<!-- Brand and toggle get grouped for better mobile display -->
							<div class="navbar-header nav_2">
								<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
							</div> 
							<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
								<ul class="nav navbar-nav">
									<li class="active"><a href="user_home.php" class="act">Home</a></li>	
									<!-- Mega Menu -->
									
									
									<li><a href="user_view_products.php">Products</a></li>
									
									<li><a href="user_view_order.php">Orders</a></li>
									<li><a href="user_blogs.php">Quick Recipe</a></li>
									
									<li><a href="../logout.php">Logout</a></li>

									
								</ul>
							</div>
							</nav>
			</div>
		</div>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {

  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {background-color: #f2f2f2;}
</style>
<form action="userpayment.php" onsubmit="return" class="oh-autoval-form" method="POST">
<?php
$storeid=$_REQUEST['storeid'];
$quantity=$_REQUEST['quantity'];
$price=$_REQUEST['price'];
$pid=$_REQUEST['pid'];
$pids=explode(',',$pid);
$pname=$_REQUEST['pname'];
$quantitys=explode(',',$quantity);
$prices=explode(',',$price);
$pnames=explode(',',$pname);

$total=$_REQUEST['total'];
$totalnew=(int)$total;
$gst=($totalnew*11)/100;
$finaltotal=$totalnew+40+$gst;
  
?>
<div class="container"></br>
<table class="w3-card-4">
<tr style="background-color: #fe9126;">
  <th style="color:white">Item Name</th>
  <th style="color:white">Quantity</th>
  <th style="color:white">Unit Price</th>
  </tr>
<?php
for($i=1;$i<sizeof($quantitys);$i++)
{	
?>
  <tr>
  <td><?php echo $pnames[$i]; ?></td>
  <td><?php echo $quantitys[$i]; ?></td>
  <td><?php echo $prices[$i]; ?></td>
 
  </tr>    
  <?php $pids[$i]; ?>
<?php
}
?>
<tr>

<td><b>Total</b></td>
<td></td>
<td>₹<?php echo $total;?></td>
  </tr>
  <tr>
<td></td>
<td></td>
<td> 
</tr>
</table> 
<?php 
$sql4="SELECT delivery FROM tbl_store WHERE storeid='$storeid' AND delivery='available' ";
$result4=mysqli_query($con,$sql4);
if(mysqli_num_rows($result4) !=0)
{
?>

<textarea placeholder="Enter Address" class="av-name" av-message="Enter a Valid Address" value="none" name="address" rows="4" cols="50">
</textarea>

<input  type="text" class="av-mobile" av-message="Enter a valid Number" name="phone" placeholder="Phone Number">
<input  type="text" class="av-required" av-message="Required" name="pincode"  placeholder="Pincode">
<?php 

}else
{	
	?>

	<div id="div3"style="padding: 20px;
  background-color:#333333;
  color: white;">
	
	<strong>Home Delivery is Not Available at this Store.You Can Collect it offline</strong>
  </div>

  <input  type="text" name="phone" placeholder="Phone Number" required="">
  <!-- <script>setTimeout(function(){ div3.style.display = "none"; }, 5000);</script> -->
	
  <script>
  $(document).ready(function(){
  
    $("#div3").fadeOut(9000);
 
   });
</script>
	
	<?php
}
 ?>
<input type="hidden" name="total" id="total" value="<?php echo $total;?>">
<input type="hidden" name="storeid" id="storeid" value="<?php echo $storeid; ?>">
<input type="hidden" name="uid" id="uid" value="<?php echo $u_id; ?>">
<input type="hidden" name="quantity" id="quantity" value="<?php echo $quantity; ?>">
<input type="hidden" name="pname" id="pname" value="<?php echo $pname; ?>">
<input type="hidden" name="pid" id="pid" value="<?php echo $pid; ?>">
<input type="hidden" name="price" id="price" value="<?php echo $price; ?>">
<input  style="background-color: #4CAF50;
  border: none;
  color: white;
 width:100%;height:50px;" type="submit" value="Proceed Payment"></br>
  
  </form>
  
 
 
 </div>  </br>
 
<?php include("userfooter.php");?> 
<?php
}
else
{
	header("location:../login.php?login");
}

?>

