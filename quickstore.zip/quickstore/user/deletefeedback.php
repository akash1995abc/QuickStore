<?php
include("../dbconnection.php");
$feedid=$_REQUEST['feedid'];
$storeid=$_REQUEST['storeid'];

$sql="DELETE FROM tbl_feedback WHERE feedid='$feedid' AND storeid='$storeid'";
$result=mysqli_query($con,$sql);
header("location:user_view_store_details.php?storeid=$storeid");


?>