<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("userheader.php");

?>
<script>

function checkout(c)
{
	var quantity=[];
	var price=[];
	var pname=[];
	var pid=[];
	var sum=0;
	var total=0;
	for(var i=1;i<c;i++)
	{
	 var n=document.getElementById('txt3'+i).value;

	 sum=sum+parseInt(n);
	 quantity[i]=document.getElementById('txt1'+i).value;
	 pid[i]=document.getElementById('pid2'+i).value;
	 price[i]=document.getElementById('txt2'+i).value;
	 pname[i]=document.getElementById('name1'+i).value;

	}
//	var quantityes=implode(",",quantity);
	document.getElementById('quantity').value=quantity;
	document.getElementById('price').value=price;
	document.getElementById('pname').value=pname;
	document.getElementById('total').value=sum;
	document.getElementById('pid').value=pid;
	

}
function rmvitem(p,s,c)
{

	// location.href = "userdeleteitem.php?storeid="+s"&productid="+p"cvalue="+c;
	$.ajax({
      type    :'POST',
      data    :{"productid":p,"storeid":s,"cvalue":c},
      url     :"userdeleteitem.php",
      success :function(result){
        
        // alert(result);
         
      }
    });
}

</script>		
<!-- //navigation -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1">
				<li><a href="user_home.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">My Basket</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<?php 
$storeid=$_REQUEST['storeid'];
$sql="SELECT * FROM tbl_basket WHERE storeid='$storeid' AND u_id='$u_id'";
$result3=mysqli_query($con,$sql);
$count=mysqli_num_rows($result3);
if($count!=0)
{
?>
<!-- checkout -->
<form action="orderitem.php" method="POST">
	<div class="checkout">
		<div class="container">
			<div class="checkout-right">
				<table class="timetable_sub">
					<thead>
						<tr>
							<th>SL No.</th>	
							<th>Product</th>
							<th>Quantity</th>
							<th>Product Name</th>
						
							<th>Price</th>
							<th style="width:45px">Remove</th>
						</tr>
					</thead>
					<?php
					$c=1;
					while($row3=mysqli_fetch_array($result3))
					{     
					 $prid=$row3['pr_id'];

						$sql4="SELECT * FROM tbl_products WHERE pr_id='$prid' AND instock>0";
						$result4=mysqli_query($con,$sql4);
						while($row4=mysqli_fetch_array($result4))
						{
					?>
					<tr class="rem1" id="rem1<?php echo $c; ?>">
						<td class="invert">Item:<?php echo $c; ?></td>
					<td class="invert-image"><a href=""><img style="width:40px;height:40px;"  src="../images/<?php echo $row4['pr_image']; ?>" alt=" " class="img-responsive" /></a></td>
						<td class="invert">
							 <div class="quantity"> 
								<div >                           
							
					<div ><input style="width:40px;" onClick=multiply(<?php echo $c; ?>) min=1 max=10  type="number" id="txt1<?php echo $c; ?>" value=1></div>
				
								</div>
							</div>
						</td>
						<td class="invert"><b><?php echo $row4['pr_name'] ?></b></td>
						
   <input style="width:25px;" type="hidden" name="pid2" id="pid2<?php echo $c; ?>" value="<?php echo $row4['pr_id'] ?>">


						<input type="hidden" id="name1<?php echo $c; ?>" value="<?php echo $row4['pr_name'] ?>">
						<input type="hidden" value=<?php echo $row4['pr_cost'] ?> id="txt2<?php echo $c; ?>">
						<td>₹<input style="border:none;width:100px"type="text" readonly id="txt3<?php echo $c; ?>" value=<?php echo $row4['pr_cost'] ?>></td>
						<script>
						function multiply(c)
						   {
							var y = document.getElementById("txt1"+ c).value;
							
							var z = document.getElementById("txt2" + c).value;
							
                            var x = +y * +z;
						   document.getElementById("txt3"+ c).value = x;
						   
						   }
						</script>
						<td class="invert">
							<div class="rem">
							<div class="close1" id="close1<?php echo $c; ?>"> <input style="opacity: 0.1;" type="button" id="removeitem" onClick="rmvitem('<?php echo $row4['pr_id'] ?>','<?php echo $storeid;?>','<?php echo $c;?>')" value="X"> </div>
							</div>
							
						</td>
					</tr>

				     	
								<!--quantity-->
								<script>
								$(document).ready(function(c) {
								$('#close1<?php echo $c; ?>').on('click', function(c){
									$('#rem1<?php echo $c; ?>').fadeOut(1000, function(c){
										$('#rem1<?php echo $c; ?>').remove();
										location.reload();
								      });
								   });	  
								});
						   </script>
							 
									 <?php $c++;  } } ?> 
						
								<!--quantity-->
							
								
				</table>
			</div>  
			        <input type="hidden" name="quantity" id="quantity">
			        <input type="hidden" name="price" id="price">
			        <input type="hidden" name="pid" id="pid">
			        <input type="hidden" name="storeid" id="storeid" value="<?php echo $storeid ?>">
			        <input type="hidden" name="pname" id="pname">
			        <input type="hidden" name="total" id="total">
			        <input type="hidden" name="cvalue" value=<?php echo $c; ?>>
			     	<input style="width:100%;height:55px;background-color:#333;color:WHITE;" type="submit" value="Continue to Checkout" onclick="checkout('<?php echo $c; ?>');">
					</form>
					
				
			
				<div class="clearfix"> </div>
			
		</div>
	</div>
							<?php 
							}
							else{
							 ?>
							 <center><h2>Your cart is Empty!</h2></center>
							<?php } ?>
	<script>
									$('.value-plus').on('click', function(){
										var divUpd = $(this).parent().find('.value'), newVal = parseInt(divUpd.text(), 10)+1;
										divUpd.text(newVal);
									});

									$('.value-minus').on('click', function(){
										var divUpd = $(this).parent().find('.value'), newVal = parseInt(divUpd.text(), 10)-1;
										if(newVal>=1) divUpd.text(newVal);
									});
									</script>
<!-- //checkout -->
<!-- //footer -->
<?php include("userfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?login");
}

?>