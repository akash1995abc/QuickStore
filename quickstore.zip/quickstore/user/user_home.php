
<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);
if($rowcount !=0 && $u_status=='Block')
{
	include("userheader.php");

?>

<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="user_home.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Select Your Location<b class="caret"></b></a>
										<ul class="dropdown-menu multi-column columns-3">
											<div class="row">
												<div class="multi-gd-img">
													<ul class="multi-column-dropdown">
														<h6 style="font-size:15px;">Select District</h6>
               <?php $sql="SELECT * FROM tbl_district";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    { ?>
					<li><a href="user_home.php?dist=<?php echo $row['distid'] ?>"><?php echo $row['dname'] ?></a></li>
														
					<?php
					}
					?>
                    </ul>
												</div>
												
												
											</div>
										</ul>
									</li>

                </ol>
		</div>
	</div>

<script>
function likestore(sid,uid){

var action="like";
$.ajax({
type    :'POST',
data    :{storeid:sid,uid:uid,action:action},
url     :"userlikestore.php",
success :function(result){
	alert(result);
	window.location.reload();
}
})



}
function dislikestore(sid,uid){
var action="dislike";
$.ajax({
type    :'POST',
data    :{storeid:sid,uid:uid,action:action},
url     :"userdislikestore.php",
success :function(result){
  
	alert(result);
	window.location.reload();
}
})

}
</script>
	


<div style="background:white;width:1300px; "class="w3-panel w3-card-2 container">
<?php           
         if(isset($_GET['dist']))
				{
				 $distid= ($_GET['dist']);
						
					$sql4="SELECT * FROM tbl_city WHERE distid='$distid'";
					$result4=mysqli_query($con,$sql4);
					while($row4=mysqli_fetch_array($result4))
					{     $city=$row4['cityid'];
				$sql="SELECT * FROM tbl_store WHERE scity='$city'";
				$result=mysqli_query($con,$sql);
				    while($row=mysqli_fetch_array($result))
				    { 
							$sid=$row['storeid'];
				?>

<div style="margin-right:63px;width:253px"class="col-md-4 top_brand_left">

<div style="border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 280px;	" class="w3-panel w3-card-2 hover14 column">
										<div style="height:480px;width:270px;" class="agile_top_brand_left_grid">
											<div class="agile_top_brand_left_grid_pos">
									<!-- <img src="../images/learnmore.png" alt=" " class="img-responsive"> -->
	
	
	<i class="fa fa-info-circle" id="details" onClick="storedetails(<?php echo $row['storeid']; ?>)" style="font-size:28px;color:#333"></i>
	
	
											</div>
										
											<div class="agile_top_brand_left_grid1">
											
												<figure>
												
													<div class="snipcart-item block">
											<div class="snipcart-thumb">
	<img style="width:100%;height:200px;margin-top:6px;" title=" " alt=" " src="../images/<?php echo $row['simage'];?>">
</br>


  <button class="like" style="border:none;background:WHITE;color:#3399ff;" onclick="likestore('<?php echo $row['storeid'];?>','<?php echo $u_id ?>')">
  <span class="fa fa-thumbs-up fa-2x"></span>
  <?php 
  $storeid=$row['storeid'];
  $sql1="SELECT * FROM tbl_like WHERE storeid='$storeid' AND action='like'";
  $result1=mysqli_query($con,$sql1);
  echo $count=mysqli_num_rows($result1);
  ?>
  </button>
  <button class="dislike" style="border:none;background:WHITE;color:#ff3333;float:right; " onclick="dislikestore('<?php echo $row['storeid'];?>','<?php echo $u_id ?>');">
    <span class="fa fa-thumbs-down fa-2x"></span>
	<?php 
  $storeid=$row['storeid'];
  $sql1="SELECT * FROM tbl_like WHERE storeid='$storeid' AND action='dislike'";
  $result1=mysqli_query($con,$sql1);
  echo $count=mysqli_num_rows($result1);
  ?>
  </button>
  

	<div>
				
			
						
					</div>
	
			<p><i class="glyphicon glyphicon-shopping-cart">&nbsp;</i><?php echo $row['sname']?></p>

			<p><i class="glyphicon glyphicon-map-marker">&nbsp;</i><?php echo $row['slandmark']?></p>
			
			<p><i class="glyphicon glyphicon-globe">&nbsp;</i><?php echo $row['slocation']?></p>
															
															
															
				</div>
					<div class="snipcart-details top_brand_home_details">
					<form action="user_select_store.php" method="post">
					<input type="hidden" id="storeid" name="storeid" value="<?php echo $row['storeid'];?>">
           <input  type="submit"  name="submit" value="Visit Store!" class="button" >
															</form>
														</div>
													</div>
												</figure>
											</div>
										</div>
									</div>
								</div>
								<script type="text/javascript">

// document.getElementById("details").onclick = function () {
// 		location.href = "user_view_store_details.php?storeid=<?php //echo $sid;?>";
// };


function storedetails(s)
{

location.href = "user_view_store_details.php?storeid="+s;
}
</script>
								
			<?php }} }?>

			
</div>


</div>

</div>


<div class="brands">
		<div class="container">
		<h3>Offer Zone</h3><p id="demo"></p>
		<?php
		 $date = date('Y/m/d');
		 
$sql65="SELECT * FROM tbl_offers WHERE date='$date'";
$result65=mysqli_query($con,$sql65);
while($row65=mysqli_fetch_array($result65))
{
?>      
				<a href="user_select_store.php?storeid=<?php echo $row65['storeid'] ?>"><img style="margin-left:10px;" src="../images/<?php echo $row65['adimg'] ?>" alt="Smiley face" height="200px" width="270px"></a>
				
				
			
<?php } ?>
			<div class="clearfix"></div>
			</div>
		</div>


		
<?php include("userfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?login");
}

?>


