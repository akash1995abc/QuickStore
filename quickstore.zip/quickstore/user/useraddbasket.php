<?php 
include("../dbconnection.php");
$uid=$_POST['uid'];
$storeid=$_POST['storeid'];
$productid=$_POST['productid'];
//$searchq= preg_replace("#[^0-9a-z]#i","",$searchq);
$sql="SELECT * FROM tbl_basket WHERE pr_id='$productid' AND storeid='$storeid' AND u_id='$uid'";
$result1=mysqli_query($con,$sql);

if(mysqli_num_rows($result1) > 0)
{    
	echo "Product Already in Basket!";
}
else
{
$result=mysqli_query($con,"INSERT INTO tbl_basket values(null,'$productid','$uid',$storeid,'na')");
echo "Added!";
}