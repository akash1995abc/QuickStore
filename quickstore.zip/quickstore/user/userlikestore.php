<?php
include("../dbconnection.php");
$storeid=$_REQUEST['storeid'];
$uid=$_REQUEST['uid'];
$action=$_REQUEST['action'];
$sql1="SELECT * FROM tbl_like WHERE uid='$uid' AND storeid='$storeid' AND action='$action'";
$result1=mysqli_query($con,$sql1);
$count=mysqli_num_rows($result1);
if($count>0)
{
    echo "already liked";
}
else
{
$sql3="DELETE FROM tbl_like WHERE uid='$uid' AND storeid='$storeid' AND action='dislike'";
$result3=mysqli_query($con,$sql3);
$sql="INSERT INTO tbl_like VALUES (null,'$uid','$storeid','$action')";
$result=mysqli_query($con,$sql);
echo "Done";
}
?>