
<?php
$con=@mysqli_connect("localhost","root","","quickstore")or die("unable to connect");
$storeid=$_POST['storeid'];
$subcatid=$_POST['subcatid'];
$uid=$_POST['uid'];
$sql="SELECT * FROM tbl_products WHERE pr_subcatid='$subcatid' AND pr_storeid='$storeid' ORDER BY pr_cost";
$result1=mysqli_query($con,$sql);

?>
 	<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="#"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<?php 
				$sql0="SELECT subcatname FROM tbl_subcategory WHERE subcatid='$subcatid'";
				$result0=mysqli_query($con,$sql0);
				$row=mysqli_fetch_array($result0);
				?>
				<li style="color:#333;" class="active"><?php echo $row['subcatname']; ?></li>

				
								
						</ul>
						    	</div>
								   	</div>
						</ul>
									</li>
			</ol>


			<script>
			function price()
			{
				alert("price");
				
				
			}
			
			</script>

<div class="products">
<div class="container">
<?php
while($row=mysqli_fetch_array($result1))
{
?>

<div style="margin:15px;width:262px" class="col-md-4 top_brand_left">
									<div style="border: 1px solid #ddd;
  border-radius: 15px;
  padding: 5px;
  width: 230px;	" class="w3-panel w3-card-2 hover14 column">
  
										<div class="agile_top_brand_left_grid">
											<div class="agile_top_brand_left_grid_pos">
												<img src="../images/offer.png" id="myimg" alt=" " class="img-responsive">
											</div>
											
											<div class="agile_top_brand_left_grid1">
											
												<figure>
													<div class="snipcart-item block">
											<div class="snipcart-thumb">
	<img style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 170px;height:180px;" title=" " alt=" " src="../images/<?php echo $row['pr_image'];?>">	

	
	
				
						<p><?php echo $row['pr_name']?></p>
							
						<h4 class="price">₹<?php echo $row['pr_cost']?>.00<span>₹<?php echo $row['pr_actcost']?>.00</span></h4>
						<?php
						$instock=$row['instock'];
						
						?>
						<p style="color:INDIGO"><?php echo $row['instock']?>-Left in Stock.</p>

						
                       
						
														</div>
						<div class="snipcart-details top_brand_home_details">
						<input type="hidden" id="prid" name="prid" value="<?php echo $row['pr_id'];?>">
						<input type="hidden" id="scid" name="scid" value="<?php echo $row['pr_subcatid'];?>">
						<input type="hidden" id="storeid" name="storeid" value="<?php echo $row['pr_storeid'];?>">
														<input type="hidden" id="uid" name="uid" value="<?php echo $uid ?>">
<input type="submit" name="submit" id="submit" value="Add to Basket" class="button" onclick="xyz('<?php echo $uid ?>','<?php echo $row['pr_storeid'];?>','<?php echo $row['pr_id'];?>'),this.value='Added' <?php if ($instock <= '10'){ ?> disabled <?php   } ?>">
															</form>
														</div>
													</div>
												</figure>
											</div>
										</div>
									</div>
								</div>

                               
<?php
    }
?>

</div>
</div> 
