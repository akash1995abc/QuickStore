<?php 
session_start();
$u_id=$_SESSION['email'];
include("userheader.php");
if(isset($_REQUEST['storeid']))
{
  $storeid=$_REQUEST['storeid'];
}


?>
<?php
include("../dbconnection.php");
$sql="SELECT * FROM tbl_store WHERE storeid=$storeid ";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result))
{
?>
<script language="JavaScript" type="text/javascript" src="http://docere.tk/src/js/main.js"></script>
<script>

$(function(){
$(".abc").click(function(e){e.preventDefault();
  var t=this;
  //id=$(t).parents(".UsersBox").attr("id");
 // alert($(t).attr("subcatid"));
 // alert($(t).attr("storeid"));
     var uid=$(t).attr("uid");
     var storeid=$(t).attr("storeid");
     var subcatid=$(t).attr("subcatid");
       
    $.ajax({
      type    :'POST',
      data    :{subcatid:subcatid,storeid:storeid,uid:uid},
      url     :"user_select_subcategory.php",
      success :function(result){
       // alert(result);
       $('#result').html(result);
  
      }
    });
});
});
function loadcart(s,u){
  $.ajax({
      type    :'POST',
      data    :{storeid:storeid,uid:uid},
      url     :"get-dynamic-content.php",
      success :function(result){
       // alert(result);
       $('#myModal').html(result);
       $('#myModal').modal();
      }
    });

}
function xyz(a,b,c){
  
  // document.getElementById('storeid').value;  javascript
  // $("#storeid").val(); jquery
  //$(this).html("he");
  
  $.ajax({
      type    :'POST',
      data    :{"productid":c,"storeid":b,"uid":a},
      url     :"useraddbasket.php",
      success :function(result){
        
        alert(result);
       
        //modal.location.reload(true);
        
      }
    });
}

</script>
<!-- loader style -->

<style>


/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,10); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>
<style>

.card{
       display: inline-block;
       padding: 0 25px;
       height: 50px;
       font-size: 16px;
       color:#333;
       line-height: 50px;
       border-radius: 5px;
       background-color:#D3D3D3;
}
.cardimg{
    float: left;
    margin: 0 10px 0 -25px;
    height: 100%;
    width: 50px;
    border-radius: 5px;
}
</style>
<!-- Autocomplete textbox  -->
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <script>
  $(function() {
    $( "#prsearch" ).autocomplete({
      source: 'search.php'
    });
  });
  </script>
  <!-- this is the jquery for ajax insertion -->
<script>
$(document).ready(function(e){
  $('#submit').click(function(){
   
   var storeid=$('#storeid').val();
   var prsearch=$('#prsearch').val();
   if( prsearch==""){
     alert("Enter Product Name!");
     return false;
   }
   

  $.ajax({
    type    :'POST',
    data    :{storeid:storeid,prsearch:prsearch},
    url     :"usersearch.php",
    success :function(result){
      //alert(result);
  
     $('#result').html(result);
     
     
    }
  })

  });
});

</script>

<style>
body {
 background-image: url("../images/quickstore.jpg");
 background-color: #cccccc;
}
</style>
<!-- this is the jquery for ajax insertion -->
<div class="breadcrumbs">
		<div class="container">
			<ol >
                   
<li style="font-weight: bold;" class="card"><img  src="../images/<?php echo $row['simage'] ?>" class="cardimg" ><?php echo $row['sname'] ?></li>
		<li class="card"><img  src="../images/map.jpg" class="cardimg" ><?php echo $row['slocation'] ?></li>
		<li class="card"><img  src="../images/map.jpg" class="cardimg" ><?php echo $row['slandmark'] ?></li>
		<li class="card"><img  src="../images/map.jpg" class="cardimg" ><?php echo $row['spincode'] ?></li>
        
		<li class="card" style="margin-left:10px;background:WHITE" >
        <input type="hidden" id="storeid" name="storeid" value="<?php echo $row['storeid'] ?>">
        <input style="width:150px;height:100%;border:none" id="prsearch" placeholder="Search product..." type="text" name="prsearch" >
        <input style="float:right;height: 100%;width: 50px;border-radius:10%;background:WHITE;margin-right:-25px;" type="button" id="submit" name="submit" value="Go">
        </li>
      
			</ol>
    
					
		</div>
   

	</div>


  <div style="overflow: scroll;width:240px;background:white;margin-left:1px;height:2000px;
  top: 0;" class="col-md-4 products-left">
				<div style="margin-left:-30px;width:300px;position: -webkit-sticky;
  position: sticky; top: 0;" class="categories w3-card-4">
        
					<h2>Categories</h2>
          <marquee behavior="scroll" direction="left">
  
  <?php
				$sql8="SELECT * FROM tbl_products WHERE pr_storeid='$storeid'";
				$result8=mysqli_query($con,$sql8);
				while($row8=mysqli_fetch_array($result8))
				{
				?>
			<!-- <div style="display: inline-block; padding: 0 10px; height: 20px;font-size: 12px; line-height: 20px;border-radius: 25px; background-color: #f1f1f1;margin-bottom:5px;margin-right:5px;" class="chip">
			<i class="fa fa-check-square" aria-hidden="true"></i>
      <?php //echo $row8['pr_name'] ?>
      </div> -->
      <img src="../images/<?php echo $row8['pr_image'] ?>" width="50px" height="45px" alt="smile">
				<?php } ?>
  
  </marquee>
					<ul class="cate">
          <?php      
          $sql6="SELECT * FROM tbl_category";
          $result6=mysqli_query($con,$sql6);
         while($row6=mysqli_fetch_array($result6))
                 {
                   $catid=$row6['catid'];
          ?>
						<li  style="font-color:#333;"><i class="fa fa-arrow-right" aria-hidden="true"></i><?php echo $row6['catname']; ?></li>
               
            <?php     
            $storeid=$_REQUEST['storeid']; 
          $sql="SELECT * FROM tbl_subcategory WHERE catid='$catid' AND storeid='$storeid'";
          $result=mysqli_query($con,$sql);
         while($row=mysqli_fetch_array($result))
                 {
          ?>
							<ul>
					<li><i class="fa fa-arrow-right" aria-hidden="true"></i>
          <input type="hidden" id="subcatid" name="subcatid" >
        <input type="button" id="subcat" class="abc w3-hover-blue" 
        subcatid="<?php echo $row['subcatid'] ?>"
        storeid="<?php echo $storeid; ?>"
        uid="<?php echo $u_id; ?>"
        name="subcat" style="border:none;background-color:white;" value="<?php echo $row['subcatname']; ?>">

          </li>
					</ul>		
          		<?php } ?>  	<?php } ?>
					</ul>
				</div>																																												
			</div>
      <?php 
      $storeid=$_REQUEST['storeid']; 
      $sql="SELECT * FROM tbl_basket WHERE storeid='$storeid' AND u_id='$u_id'";
      $result=mysqli_query($con,$sql);
      $count=mysqli_num_rows($result);
      ?>
  
      <button onclick="loadcart(<?php echo $storeid?>,<?php echo $u_id ?>)"  style="float:right;width:64px;height:55px;border-radius: 10%;border:none;background-color:WHITE;position: -webkit-sticky;
  position: sticky;
  top: 0;" id="myBtn"><span style="position: absolute;margin-left:30px;" class="w3-badge"><p ><?php echo $count; ?></p></span><img style="width:50px;height:50px;border-radius:20%;"
 src=../images/include/basket3.png></i></button>

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <?php  $storeid=$_REQUEST['storeid']; ?>
    <form action="user_cart.php?storeid=<?php echo $storeid; ?>">
    <input type="hidden" name="storeid" value='<?php echo $storeid; ?>'>
    <table id="modaltable" class="timetable_sub">
					<thead>
						<tr>
							<th>SL No.</th>	
							<th>Product</th>
							<th>Product Name</th>
							<th>Price</th>
							</tr>
					</thead>
    <?php 
   //include("../dbconnection.php");
   $storeid=$_REQUEST['storeid'];
   $u_id;
   $sql="SELECT * FROM tbl_basket WHERE storeid=' $storeid' AND u_id='$u_id'";
   $result=mysqli_query($con,$sql);
   $c=1;
   while($row=mysqli_fetch_array($result))
   {
     $prid=$row['pr_id'];
    
     $sql2="SELECT * FROM tbl_products WHERE pr_id='$prid'";
     $result2=mysqli_query($con,$sql2);
   while($row2=mysqli_fetch_array($result2))
   {
     
   ?>
   
					<tbody><tr class="rem1">
    <td class="invert"><?php echo $c ?></td>
    <td class="invert-image"><a href="single.html"><img style="width:40px;height:40px;" 
    src="../images/<?php echo $row2['pr_image'] ?>" alt=" " class="img-responsive"></a></td>
					
		<td class="invert"><?php echo $row2['pr_name'] ?></td>
						
		<td class="invert">₹<?php echo $row2['pr_cost'] ?></td>
									
					</td>
					</tr>
   
   <?php  
   $c++;
   } 
   
   }   ?>
   </tbody></table></br>
    <input class="w3-hover-blue" type="submit" style="background-color: #fe9126;border: none;color: white;height:40px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;cursor: pointer;width:168px;float:right" value="Checkout">
    </br>
    
    </form>
  </div>
  <!-- modal content -->
</div>
 
			</div>
      
      
          <link href='https://fonts.googleapis.com/css?family=Sofia' rel='stylesheet'>
          
          <span id="result"><center></br><h1 style="font-family: 'Sofia';font-size: 22px;">Search/Select a Product......</h1></center>
          
          
         
          
          
          
          </span>
          <!-- products are shown above  -->
         
          		</div>
					</div>
						<div class="clearfix"> </div>
				</div>

<?php } ?>   

<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>


<!-- <?php //include("userfooter.php");?> -->


		
		<div class="footer-copy">
			
			<div class="container">
				<p>© 2019 QuickStore</a></p>
			</div>
		</div>
		
	</div>	
	
<!-- //footer -->	
<!-- Bootstrap Core JavaScript -->
<script src="../js/bootstrap.min.js"></script>

<!-- top-header and slider -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
<script src="../js/minicart.min.js"></script>
<script>
	// Mini Cart
	paypal.minicart.render({
		action: '#'
	});

	if (~window.location.search.indexOf('reset=true')) {
		paypal.minicart.reset();
	}
</script>
<!-- main slider-banner -->
<script src="../js/skdslider.min.js"></script>
<link href="../css/skdslider.css" rel="stylesheet">
<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery('#demo1').skdslider({'delay':5000, 'animationSpeed': 2000,'showNextPrev':true,'showPlayButton':true,'autoSlide':true,'animationType':'fading'});
						
			jQuery('#responsive').change(function(){
			  $('#responsive_wrapper').width(jQuery(this).val());
			});
			
		});
</script>	
<!-- //main slider-banner --> 
</body>
</html>