<?php 
include("../dbconnection.php");
session_start();
$uid=$_SESSION['email'];
$storeid=$_POST['storeid'];
$prsearch=$_POST['prsearch'];
//$searchq= preg_replace("#[^0-9a-z]#i","",$searchq);
$sql="SELECT * FROM tbl_products WHERE pr_name='$prsearch' AND pr_storeid='$storeid'";
$result1=mysqli_query($con,$sql);
$count = mysqli_num_rows($result1);
if($count == 0){

    ?>
    <h4>No Results Found in this Store,Look in another store!!!</h4>
    <?php
    
}
else{

// header("location:store_home.php?text=Added!");
?>
<div class="products">

	
<div class="container">
<?php
while($row=mysqli_fetch_array($result1))
{
?>


<div style="margin:15px;width:262px" class="col-md-4 top_brand_left">
									<div style="border: 1px solid #ddd;
  border-radius: 15px;
  padding: 5px;
  width: 230px;	" class="w3-panel w3-card-2 hover14 column">
										<div class="agile_top_brand_left_grid">
											<div class="agile_top_brand_left_grid_pos">
												<img src="../images/offer.png" alt=" " class="img-responsive">
											</div>
											<div class="agile_top_brand_left_grid1">
												<figure>
													<div class="snipcart-item block">
											<div class="snipcart-thumb">
	<a href="products.html"><img style="border: 1px solid #ddd; border-radius: 4px; padding: 5px; width: 150px;height:180px;" title=" " alt=" " src="../images/<?php echo $row['pr_image'];?>"></a>		
															<p><?php echo $row['pr_name']?></p>
														
															<h4>₹<?php echo $row['pr_cost']?>.00<span>₹<?php echo $row['pr_actcost']?>.00</span></h4>
															<p style="color:INDIGO"><?php echo $row['instock']?>-Left in Stock.</p>
														</div>
													<div class="snipcart-details top_brand_home_details">
													<input type="hidden" id="prid" name="prid" value="<?php echo $row['pr_id'];?>">
													<input type="hidden" id="scid" name="scid" value="<?php echo $row['pr_subcatid'];?>">
													<input type="hidden" id="storeid" name="storeid" value="<?php echo $row['pr_storeid'];?>">
													<?php
														$instock=$row['instock'];
						
														?>
<input type="submit" 
storeid="<?php echo $row['pr_storeid'] ?>"
prid="<?php echo $row['pr_id'] ?>"
name="submit" value="Add to Basket"  onclick="xyz('<?php echo $uid ?>','<?php echo $row['pr_storeid'];?>','<?php echo $row['pr_id'];?>')"  <?php if ($instock <= '10'){ ?> disabled <?php   } ?> class="button">
 
															</form>
														</div>
													</div>
												</figure>
											</div>
										</div>
									</div>
								</div>

                               
<?php }
}
?>
</div>
    </div> 