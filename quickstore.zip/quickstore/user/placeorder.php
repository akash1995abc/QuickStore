<?php 
include("../dbconnection.php");
$quantity=$_REQUEST['quantity'];
$cardnumber=$_REQUEST['cardnumber'];
$transid='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
$transid = str_shuffle($transid);
$transid = substr($transid,0, 20);

 $code = '123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $code = str_shuffle($code);
  $code = substr($code,0, 10);
$ordernumber=$code;
    $storeid=$_REQUEST['storeid'];

$pname=$_REQUEST['pname'];
$pid=$_REQUEST['pid'];

$price=$_REQUEST['price'];
    $uid=$_REQUEST['uid'];

if(isset($_POST['phone'])){

    $phone=$_REQUEST['phone'];
    
}else
{
    $phone="Offline PickUp";
}
if(isset($_POST['pincode'])){

    $postcode=$_REQUEST['pincode'];

}else
{
    $postcode="Offline PickUp";
}
if(isset($_POST['address'])){

    $address=$_REQUEST['address'];

}else
{
    $address="Offline PickUp";
}


     $total=$_REQUEST['total'];
     $totalnew=(int)$total;
     $gst=($totalnew*11)/100;
     $finaltotal=$totalnew+40+$gst;
       
 $pin= mt_rand(1000, 9999);

     $date=date("d/m/Y");
$sql="INSERT INTO tbl_order values('','$ordernumber','$pid','$pname','$price','$quantity',$gst,'$uid',$pin,$storeid,'$date','$address','$phone','$postcode','success','ND','$finaltotal','Txn-$transid','$cardnumber','nil')";

$result=mysqli_query($con,$sql);
if($result){
    $quantitys=explode(',',$quantity);
    $pids=explode(',',$pid);
    for($i=1;$i<sizeof($pids);$i++)
    {    
        $sql11="SELECT * FROM tbl_products WHERE pr_id='$pids[$i]'";
        $result11=mysqli_query($con,$sql11);
        $row11=mysqli_fetch_array($result11);
        $stock=$row11['instock'];
        $total=$stock-$quantitys[$i];
        mysqli_query($con,"UPDATE tbl_products SET instock='$total' WHERE pr_id='$pids[$i]'");
    }
    header("location:user_view_order.php?text=OrderPlaced!!!&txnid=$transid");
}else{

    echo "Not inserted";
}


?>