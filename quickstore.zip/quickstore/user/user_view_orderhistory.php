<style>
    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
    }
    
    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
        
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }
    
    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }
    
    .rtl table {
        text-align: right;
    }
    
    .rtl table tr td:nth-child(2) {
        text-align: left;
    }

    </style>


    
<?php 
session_start();
include("../dbconnection.php");
$u_id=$_SESSION['email'];
$u_pass=$_SESSION['u_pass'];
$u_status=$_SESSION['u_status'];

$sql2="SELECT * FROM tbl_user WHERE email='$u_id'";
$result2=mysqli_query($con,$sql2);
$rowcount=mysqli_num_rows($result2);

if($rowcount !=0 && $u_status=='Block')
{
	include("userheader.php");
  
?>
<input type="button" value="Pending Orders" style="float:left; background-color: #008CBA;
  border: none;
  color: white;
  padding: 15px 72px;
  text-align: center;
  text-decoration: none;
  font-size: 16px;" onclick="document.location.href='user_view_order.php';">

 <?php

$sql4="SELECT * FROM tbl_order WHERE u_id='$u_id' AND orderstatus!='ND' ";
$result4=mysqli_query($con,$sql4);
$count=mysqli_num_rows($result4);
while($row4=mysqli_fetch_array($result4))
{

 ?>
 <div id="div32"class="container">
  <div class="invoice-box" >
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="2">
                    <table>
                        <tr>
                            <td class="title">
                            <p><img style="width:80px;height:80px;" src="../images/qr.jpg">  QuickStore   <img style="width:80px;height:80px;" src="../images/Q1.jpg"></p>
                           
                            
                            </td>
                            
                            <td>
                                Invoice #: <?php echo $row4['ord_id']?><br>
                                Created:<?php echo $row4['date']?><br>
                                Order:ORD-<?php echo $row4['ordernumber']?><br>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <form action="user_cancel_order.php" method="POST">
            <tr class="information">
                <td colspan="2">
                    <table>
                        <tr>
                           
                            <td><br>
                            <b>Delivery address</b><br>
                            <?php echo $row4['address']?>
                            </td>
                            <?php $storeid= $row4['storeid']; ?>
                            <td>
                            <?php
                                   $sql5="SELECT * FROM tbl_store WHERE storeid='$storeid'";
                                   $result5=mysqli_query($con,$sql5);
                                   $row5=mysqli_fetch_array($result5);
                            ?>
                               <b>Store</b>
                               <br>
                                <?php echo $row5['slandmark']; ?> 
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Payment Status
                </td>
                
                <td>
                    Total
                </td>
            </tr>
            
            <tr class="details">
                <td>
                <?php echo $row4['status']?>
                </td>
                
                <td>
                ₹<?php echo $row4['total']?>
                </td>
            </tr>

    
            <tr class="heading">
                <td>
                    Item List
                </td>
                
                <td>
                    Price List
                </td>
            </tr>
            <?php
            // $sql6="SELECT * FROM tbl_order WHERE u_id='$u_id' AND storeid='$storeid'";
            // $result6=mysqli_query($con,$sql6);
            // while($row6=mysqli_fetch_array($result6))
            // {
            $pr_namelist=$row4['pr_namelist'];
            $pr_idlist=$row4['pr_idlist'];
            $pr_pricelist=$row4['pr_pricelist'];
            $pr_qtylist=$row4['pr_qtylist'];
            
            $explodedname=explode(',',$pr_namelist);
            $explodedprice=explode(',',$pr_pricelist);
            $explodedqty=explode(',',$pr_qtylist);
            
            $i=1;
            for($i=1;$i<sizeof($explodedqty);$i++)
            {
            ?>
            <tr class="item">
                <td>
               <?php echo $explodedname[$i]; ?>
                </td>
                
                <td>
                ₹<?php echo $explodedprice[$i] ;?>*<?php echo $explodedqty[$i]; ?>
                </td>
            
            </tr>
            <input type="hidden" name="pridlist<?php echo $i; ?>" value="<?php echo $pr_idlist ?>">
               <input type="hidden" name="prqtylist<?php echo $i; ?>" value="<?php echo $pr_qtylist ?>">
            <?php } ?>


            <tr class="item">
                <td>
                    Shipping Cost
                </td>
                
                <td>
                ₹<?php echo $row5['shippingcost']; ?> 
                </td>
            </tr>
            
            <tr class="item last">
                <td>
                    GST
                </td>
                
                <td>
                ₹<?php echo $row4['gst']?>
                </td>
            </tr>
            
            <tr class="total">
                <td></td>
                </form>
                <td>
                   Total:₹<?php echo $row4['total']?>
                </td>
            </tr>
            <tr class="heading" >
                <td>
                    Delivery Status
                </td>
                
                <td>
                    Pin
                </td>
            </tr>
            <tr class="details" >
                <td >
                <?php 
                
                if($row4['orderstatus']=='ND')
                {
                    echo "Not Delivered!";
                }else
                {
                    echo $row4['orderstatus'];
                }

                
                ?>
                </td>
                
                <td>
                Expired
                </td>
            </tr>
        </table>
    </div>
    <hr>
</div>


<?php  
}
?>

<?php include("userfooter.php");?>
<?php
 }
else
{
	header("location:../login.php?login");
}

?>