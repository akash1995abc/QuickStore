<?php 
include("../dbconnection.php");
$ingredients=$_REQUEST['ingredients'];
echo$title=$_REQUEST['title'];
echo$content=$_REQUEST['content'];
echo$author=$_REQUEST['author'];
echo$type=$_REQUEST['type'];
echo$serves=$_REQUEST['serves'];
echo$content=$_REQUEST['content'];
echo$uid=$_REQUEST['uid'];
$notes=$_REQUEST['notes'];
$date=date('d/m/y');
 echo $fileimage = time().$_FILES['photo']['name'];
 move_uploaded_file($_FILES['photo']['tmp_name'],"../images/".$fileimage);
$sql="INSERT INTO tbl_blogs VALUES(null,'$title','$author','$type','$serves','$ingredients','$content','$notes','$fileimage','$uid','$date','Block')";
$result=mysqli_query($con,$sql);
header("location:user_blogs.php?msg=inserted");

?>