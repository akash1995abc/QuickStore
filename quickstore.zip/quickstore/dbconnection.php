<?php 
$con=@mysqli_connect("localhost","root","","quickstore")or die("unable to connect");

?>