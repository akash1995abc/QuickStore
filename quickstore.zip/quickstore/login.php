<?php include("header.php");?>
<style>
.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>
<style>
body {
 background-image: url("images/qstore.jpg");
 background-color: #cccccc;
}

</style>
<!-- //navigation -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Login Page</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->

<!-- login -->
	<div class="login">
		<div class="container">
	
		
		
			<div class="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
			<h2>Login Form</h2>
			<?php
if(isset($_GET['error']))
{
	$text=$_GET['error'];
	?>
	<div class="alert">
	<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
	<strong><?php echo $text ?></strong>
  </div>
  <?php
}
	?>
				<form action="loginaction.php" onsubmit="return" class="oh-autoval-form" name="login" method="post">
					<input type="email" class="av-email"  av-message="enter valid E-mail" name="lemail" placeholder="Email Address" required=" " >
					<input type="password"  name="lpassword" placeholder="Password" required=" " >
					<div class="forgot">
						<a href="forgot.php">Forgot Password?</a>
					</div>
					<input type="submit" value="Login">
				</form>
				<h4>For New People</h4>
			<p><a href="signup.php">SignUp</a> (Or) go back to <a href="index.php">Home<span class="glyphicon glyphicon-menu-right" aria-hidden="true"></span></a></p>
			</div>
			
		</div>
	</div>
<!-- //login -->
<?php include("footer.php");?>